# 整机 Description 与仿真接入：Agent 交接

更新日期：2026-10-09。对象：负责将本机器人导入其他仿真环境的同事及其 agent。
以下命令默认在本仓库根目录执行；数值是本次交接快照，后续以源配置及生成 manifest 为准。

## 1. 接手任务与唯一模型入口

先把 **pedestal_01 底座 + chest_02 双臂转接件 + AR5 左右七轴臂 + DH116S 左右手**
作为固定基座整机导入目标仿真器，再配置该仿真器的驱动、碰撞与任务场景。

**直接读取 [整机 URDF](../../src/robot/robot_assembly_factory/generated/robot.urdf)。**
它已展开装配关系，不需要运行 Xacro、硬件驱动、Quest、WBC 或 Newton 才能读取。

| 文件／目录 | 用途 |
|---|---|
| `src/robot/robot_assembly_factory/generated/robot.urdf` | 带双手的完整模型，是此次仿真导入入口 |
| 同目录 `assembly_manifest.json` | 组件来源、安装变换、26 个独立关节初值、手部有效范围、输入及 URDF 哈希 |
| 同目录 `joint_state_publisher.yaml` | ROS 显示初值，`/**.ros__parameters.zeros`；不是仿真驱动参数 |
| `src/robot/rokae_ar5/description` | ROS 包名仍为 `rokae_ar5`，提供平台和双臂源 URDF／网格 |
| `src/robot/leadtron_lhand/hand_control_description` | 提供 DH116S 左右手源 URDF／网格 |

`rokae_ar5/description/urdf/rokae_ar5.urdf` 是不带手的源模型，不能替代整机产物。
`rokae_ar5/rokae_description` 中厂商单臂为 `AR5-5_07L/R-W4C4A2`，
当前整机使用 `AR5-5_08L/R-W4C4A6-ZY2`。保留当前整机型号、关节名和运动学，
不要因为两者都叫 AR5 就混用。旧 `src/robot/rokae_ros2-v0.0.4` 已整合进 `rokae_ar5`。

## 2. 当前使用的 config

### 模型装配：本次交接必须使用

以下路径均相对 `src/robot/robot_assembly_factory/`：

| 配置 | 当前选择／作用 |
|---|---|
| [config/assemblies/rokae_ar5_dh116s.yaml](../../src/robot/robot_assembly_factory/config/assemblies/rokae_ar5_dh116s.yaml) | schema 2，机器人名 `rokae_dual_arm_with_dh116s`，默认整机配方 |
| `config/components/platforms/pedestal_01_chest_02.yaml` | 从 `rokae_ar5` 提取平台，左右肩接口均为 `chest_link` |
| `config/components/arms/ar5_left.yaml`、`ar5_right.yaml` | 左右臂子树、法兰接口、各 7 个关节初值 |
| `config/components/end_effectors/dh116s_left.yaml`、`dh116s_right.yaml` | DH116S-L000-A1／R000-A1，加 `left_hand_`／`right_hand_` 前缀，启用 mimic 限位交集 |
| [config/mounts/ar5_dh116s.yaml](../../src/robot/robot_assembly_factory/config/mounts/ar5_dh116s.yaml) | 法兰到手基座：平移均为零；左手绕法兰 Z 轴 +π/2，右手 −π/2 |

重新生成及检查（生成器需要 Python 3 + PyYAML，完整性测试仅用标准库）：

```bash
python3 src/robot/robot_assembly_factory/tools/build_robot.py --package-root src/robot
python3 src/robot/rokae_ar5/description/test/test_assets.py
python3 src/robot/robot_assembly_factory/test/test_assets.py src/robot/robot_assembly_factory
python3 src/robot/robot_assembly_factory/test/test_factory.py
```

仅取走当前描述时可直接使用已生成文件。改变配方、安装变换、源 URDF 或初值后，
必须重新生成；不要手改 `generated/` 来形成另一套模型来源。
改变几何／安装关系后，本项目原有碰撞胶囊及其他派生产物也需要重新校验。

### 控制、显示及物理参数：按需参考

| 配置 | 当前用途及关键值 |
|---|---|
| [src/hexabot_bringup/config/robot_display.yaml](../../src/hexabot_bringup/config/robot_display.yaml) | `robot_display`：整机 + 滑块 + RViz，`gui=true`、`rviz=true` |
| [src/hexabot_bringup/config/teleop_wbc_ik.yaml](../../src/hexabot_bringup/config/teleop_wbc_ik.yaml) | Quest → WBC → 整机显示；指向 `package://wbc_ik/config/wbc_config.yaml` |
| [src/motion_control/wbc_ik/config/wbc_config.yaml](../../src/motion_control/wbc_ik/config/wbc_config.yaml) | 当前 ROS WBC 配置，100 Hz，超时 0.25 s，最大控制 dt 0.02 s；自定义速度限制关闭；自碰撞检查当前关闭 |
| [src/newton_simulation/src/newton_simulation/config/default.yaml](../../src/newton_simulation/src/newton_simulation/config/default.yaml) | Newton 独立物理场景／驱动／IK 配置，物理 dt=0.001 s、控制 100 Hz；与 ROS WBC YAML 是两个配置入口 |

WBC 当前双腕位置／姿态权重为 50／1，posture 权重 0.01、动能正则权重 0.001；
manipulability 与 continuity 关闭；TCP offset 为单位变换。WBC 求解 14 个机械臂自由度，
双手保持 init。**导入整机 description 无需安装或加载这些 IK 参数。**

Newton 中的 PD、armature、手部 effort／velocity、mimic 约束刚度等是仿真调参值，
不是辨识得到的真实硬件参数。移植到其他引擎时显式建立对应参数；
不能把 WBC task 权重当作关节 PD 刚度，也不能把 URDF 当作已包含执行器的完整物理场景。

## 3. 最短交付路径：导出不依赖 ROS 的资源包

原始 URDF 的网格是 `package://` URI。支持 package resolver 的导入器可直接设置：

| URI 包名 | 本仓库目录 |
|---|---|
| `rokae_ar5` | `src/robot/rokae_ar5/description` |
| `hand_control_description` | `src/robot/leadtron_lhand/hand_control_description` |

不支持该 URI 的导入器，推荐执行以下完整命令。它只用 Python 标准库，复制当前模型
实际引用的网格，将导出 URDF 的路径改成相对于该 URDF 的路径，并保留源产物、
配置快照、原始包许可声明、初始关节值及文件哈希。每次生成新的 `/tmp` 目录，
不改仓库文件；终端最后打印目录和可发给同事的 `.tar.gz` 路径。

```bash
python3 - <<'PY'
from pathlib import Path
import hashlib, json, shutil, tarfile, tempfile
import xml.etree.ElementTree as ET

repo = Path.cwd()
factory = repo / 'src/robot/robot_assembly_factory'
packages = {
    'rokae_ar5': repo / 'src/robot/rokae_ar5/description',
    'hand_control_description': repo / 'src/robot/leadtron_lhand/hand_control_description',
}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((factory / 'generated/assembly_manifest.json').read_text())
assert sha(factory / 'generated/robot.urdf') == manifest['urdf_sha256']
for rel, digest in manifest['config_sha256'].items():
    assert sha(factory / rel) == digest, rel
for uri, digest in manifest['source_urdf_sha256'].items():
    owner, rel = uri.split('/', 1)
    assert sha(packages[owner] / rel) == digest, uri

out = Path(tempfile.mkdtemp(prefix='rokae-description-'))
def copy(src, rel):
    dst = out / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

for rel in manifest['config_sha256']:
    copy(factory / rel, 'assembly_source/' + rel)
for name in ('robot.urdf', 'assembly_manifest.json', 'joint_state_publisher.yaml'):
    copy(factory / 'generated' / name, 'assembly_source/generated/' + name)
for uri in manifest['source_urdf_sha256']:
    owner, rel = uri.split('/', 1)
    copy(packages[owner] / rel, 'resources/' + uri)
for owner, path in packages.items():
    copy(path / 'package.xml', f'resources/{owner}/package.xml')
copy(factory / 'package.xml', 'assembly_source/package.xml')
copy(repo / 'docs/design_docs/whole_robot_simulation_handoff.md', 'HANDOFF.md')

tree = ET.parse(factory / 'generated/robot.urdf')
for mesh in tree.findall('.//mesh'):
    uri = mesh.get('filename')
    assert uri.startswith('package://'), uri
    owner, rel = uri[10:].split('/', 1)
    assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
    target = f'resources/{owner}/{rel}'
    copy(packages[owner] / rel, target)
    mesh.set('filename', target)
tree.write(out / 'robot.urdf', encoding='utf-8', xml_declaration=True)

q = dict(manifest['initial_positions_rad'])
pending = {j.get('name'): j.find('mimic').attrib
           for j in tree.findall('joint') if j.find('mimic') is not None}
while pending:
    ready = [name for name, m in pending.items() if m['joint'] in q]
    assert ready, 'Unresolved mimic dependency'
    for name in ready:
        m = pending.pop(name)
        q[name] = q[m['joint']] * float(m.get('multiplier', 1)) + float(m.get('offset', 0))
(out / 'joint_positions_rad.json').write_text(json.dumps(q, indent=2) + '\n')
metadata = {
    'source_urdf_sha256': manifest['urdf_sha256'],
    'portable_urdf_sha256': sha(out / 'robot.urdf'),
    'files_sha256': {str(p.relative_to(out)): sha(p) for p in sorted(out.rglob('*')) if p.is_file()},
}
(out / 'bundle_manifest.json').write_text(json.dumps(metadata, indent=2) + '\n')
archive = Path(str(out) + '.tar.gz')
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(out, arcname=out.name)
print(out)
print(archive)
PY
```

解压后，将顶层 `robot.urdf` 的**绝对路径**交给目标引擎；网格相对于该文件所在目录解析。
如果引擎按进程工作目录解析相对路径，将其资源根设为解压目录，或在引擎适配层转为绝对路径。
这个目录中的 `resources/*/package.xml` 用于保留包身份／许可，不代表它是可 colcon 构建的完整源码包。
`HANDOFF.md` 的源码链接指向原仓库；离线导入只需遵循文中的目录及数据约定。

`assembly_source/generated/robot.urdf` 保留原始 URI 和原始哈希；顶层 `robot.urdf` 是便携派生文件，
二者哈希不同是预期行为。`bundle_manifest.json` 单独记录两者，不能用改路径后的文件覆盖源哈希。
本次快照共有 71 个不同网格文件，约 119 MB（未压缩），122 处 visual／collision 网格引用。

如果只需要静态查看，也应按下一节的 init 设置关节；URDF 零位不是项目 init。

## 4. 导入后必须保持的模型约定

### 固定基座、单位与坐标

- 根坐标系 `base_link`，模型长度为米、关节角为弧度；项目场景使用 X 前、Y 左、Z 上。
- 按固定基座导入；当前模型没有浮动底盘或可驱动腰关节。平台／胸部均为固定结构。
- mesh `scale` 混合使用 `1` 与 `0.001`，按 URDF 原值保留；不要再统一缩放全部 STL。
- `base_link → waist_mount` 平移 `[0, 0, 0.856]` m；`waist_mount → chest_link` 绕 Z 转 +π/2。
- `chest_link` 下左肩平移 `[0.112, 0, 0.196]`、绕 Y 转 +π/2；右肩平移 `[-0.112, 0, 0.196]`、绕 Y 转 −π/2。
- 当前左右手在 init 掌心朝下，安装绕法兰 Z 轴分别为 +π/2、−π/2；这是固定安装关系，不是持续锁定掌心朝地的控制任务。

### 关节与初始化

原始树有 **56 links、55 joints = 19 fixed + 36 revolute**。
36 个转动关节中 **26 个独立 = 14 臂 + 12 手**，另有 **10 个 mimic**。
仿真引擎可能合并 fixed links 或为 mimic 保留额外物理坐标，应按名称建立映射，不能假定内部 q 向量一定是 26 维。

| 部位 | 独立关节名称 |
|---|---|
| 左臂 | `AR5-5_08L-W4C4A6-ZY2_joint_1` 至 `_joint_7` |
| 右臂 | `AR5-5_08R-W4C4A6-ZY2_joint_1` 至 `_joint_7` |
| 左手 | 前缀 `left_hand_` + 后缀 `finger11`、`finger12`、`finger21`、`finger31`、`finger41`、`finger51` |
| 右手 | 同样 6 个名称，前缀改为 `right_hand_` |

初值唯一来源为 `assembly_manifest.json.initial_positions_rad`，完整精度按该字典读取。
左臂 J1…J7 的 init 为 `[0, π/2, −π/2, 85°, 0, 0, 0]`，右臂为 `[0, −π/2, −π/2, 85°, 0, 0, 0]`；
其中 85° 在文件中以弧度 `1.4835298641951802` 存储。两手独立关节依次为
`[0, 0.007912622218025698, 0.04595175453035239, 0.05639937701692236, 0.05426452180070969, 0.06524878659662828]` rad。

每只手的 `finger13/22/32/42/52` 分别跟随 `finger12/21/31/41/51`，
关系严格使用 URDF `<mimic>` 的 `q_follower = multiplier × q_driver + offset`。
从动关节不接受独立动作。上面的便携包额外生成 `joint_positions_rad.json`，包含展开后的全部 36 个转动关节初值。

同时应用 URDF 硬限位、`safety_controller` 中的有效范围，及 manifest 的 `hand_gui_bounds`。
该范围来自驱动和从动关节限位的交集。不能因引擎忽略 `safety_controller` 就把手指驱动下界全部设成 0。

### TCP 与固定链接合并

左 TCP 为 `AR5-5_08L-W4C4A6-ZY2_flan_link`，右 TCP 为 `AR5-5_08R-W4C4A6-ZY2_flan_link`。
本项目约定 **物理法兰即 TCP**，没有额外手心或指尖 offset。
`link7 → flan_link` 的 `0.09 m` 结构偏移已在 URDF 固定关节中，不要重复加 90 mm。
手基座是 `left_hand_base_link`／`right_hand_base_link`，不能用它们替代 TCP。
合并 fixed links 时保留法兰、手基座、胸部等查询 frame/site，或记录合并后的等价变换。

## 5. 物理仿真需要目标环境补充的内容

模型可用于几何与运动学接入，但以下内容不能从“成功加载 URDF”推断为已经完成：

1. **执行器与惯量处理**：整机 URDF 未配置目标仿真器的 actuator、PD、摩擦、阻尼或接触材料。
   `base_link`、`waist_mount`、`chest_link`、`pedestal_01_link` 和两臂 `*_base` 缺少惯量，
   两个 `*_flan_link` 的质量为 0。平台按静态固定体处理；末端固定链接合并时保持已有非零质量／惯量和查询 frame。
   若引擎要求额外动力学值，在仿真适配配置中记录假设，不回填成厂家实测参数。
2. **手部速度和力矩**：官方手 URDF 的 velocity 为 0，不能将其当成已提供有效的控制速度上限。
   Newton 当前手部配置 velocity=1.5 rad/s、effort=0.3、kp=0.8、kd=0.03，仅供参考。
   URDF 没有最大加速度参数；WBC 的软正则也不等价于加速度硬限制。
3. **mimic**：纯运动学回放可展开从动角；物理交互应实现目标引擎的耦合／等式约束，验证接触下仍遵守关系，
   不给 10 个从动关节另设独立位置驱动。
4. **碰撞**：保留高精度 visual，碰撞几何按引擎要求处理。当前底座有 19 个碰撞子网格，
   整机还包含原始臂／手网格；不能默认直接作为动态凹三角网格使用。
   Newton 适配会生成凸包、排除相邻 link 接触，并配置 4 对有原因记录的装配重叠排除，
   见 `default.yaml.collision_exclusions` 与 [world.py](../../src/newton_simulation/src/newton_simulation/world.py)。
   该排除策略依赖几何处理方式；移植后逐对验证，不要关闭整机全部自碰撞。
5. **碰撞检查范围**：WBC 当前 `self_collision.enabled=false`；即使打开，已有胶囊也仅覆盖跨臂／双手，
   不代表全身或环境避障。不要将这份开关或胶囊当作仿真器的完整接触配置。
6. **实物与传感器**：当前平台／转接件模型、腕部安装可作为仿真基线，实际底座版本、转接板厚度、孔系和标定仍有待核实项。
   当前生成 URDF 不含已标定的相机／传感器模型；任务相机、桌面、物体、灯光由目标场景另配。

## 6. 在本仓库预览与对照

仅为核对外观和安装姿态，可在 ROS 2 Humble 环境构建显示依赖：

```bash
source /opt/ros/humble/setup.bash
colcon --log-base log/description_handoff build \
  --base-paths src/robot/rokae_ar5/description src/robot/robot_assembly_factory \
    src/robot/leadtron_lhand/hand_control_description \
    src/robot/leadtron_lhand/hand_control_interfaces \
    src/third_party/joint_state_publisher \
  --build-base build/description_handoff --install-base install \
  --packages-up-to robot_assembly_factory
./view_robot.sh
```

这是模型显示入口，不启动机械臂／灵巧手驱动；可追加 `gui:=false rviz:=false` 做无图形状态发布。
本项目当前 display launch 会定位工作区源配置，并核对安装资产的哈希，
**只复制 install/share 或 portable bundle 后不能依赖这个项目 launch 独立启动**；
目标仿真器直接读 URDF，若需要 ROS TF，则自行用该 URDF 配置 `robot_state_publisher` 并发布仿真关节状态。

已有 Newton 环境可用 `./src/newton_simulation/run.sh --headless --demo --seconds 10` 对照，
首次运行会准备较完整的仿真／IK 依赖；拿 description 的同事无需先跑它。

## 7. 接收方 Agent 的验收与回传

先完成静态导入和 init 姿态，再启用重力、驱动、接触和任务动作。回传以下结果：

- 使用的源 URDF SHA-256、导出文件哈希、目标引擎及版本、资源路径解析方式。
- 所有网格加载成功，无重复毫米缩放；原始树为 56 links／55 joints，说明 fixed 合并后的数量变化。
- 26 个独立关节的名称到引擎索引映射，以及 10 个 mimic 的实现方式。
- init 下底座／胸部／双臂／手的截图，确认两手掌心朝下、左右手未交换。
- 在 init 和至少一组非零关节角下，左右法兰相对 `base_link` 的 FK 与源 URDF 对比；
  建议作为导入回归采用平移误差 ≤1e-5 m、旋转角误差 ≤1e-5 rad，并报告实测误差。
- 手指全行程限位和 mimic 关系；开启接触后报告是否穿透、抖动或出现耦合漂移。
- 列出新增的驱动参数、碰撞近似、过滤对和惯量处理，注明假设，保留源 description 不变。

本次交接模型 SHA-256：
`7c648f03f6d619be06f6e406e2e775eb7474bbf70e17a065bd82f13ad5168496`。
若收到的 manifest 不同，先核对双方的配方／安装参数版本，不硬改哈希使校验通过。
交接文档描述的是模型和接入约定，不代表接收方仿真任务或真机标定已经验收。
