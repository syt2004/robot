#!/usr/bin/env python3
import argparse,os,json,time,subprocess,signal,hashlib,xml.etree.ElementTree as ET
from pathlib import Path
import rclpy,numpy as np
from rclpy.qos import QoSProfile,DurabilityPolicy,ReliabilityPolicy
from sensor_msgs.msg import JointState
from std_msgs.msg import String
from tf2_msgs.msg import TFMessage
from ament_index_python.packages import get_package_share_directory
from scipy.spatial.transform import Rotation
from PyQt5.QtWidgets import QApplication
ap=argparse.ArgumentParser(description='Run installed Humble package, headless then GUI; requires a visible or virtual X display.');ap.add_argument('--output-package',type=Path,default=Path(__file__).resolve().parents[1]);args=ap.parse_args();pkg=Path(get_package_share_directory('robot_assembly_factory'));out=args.output_package.resolve()/'config';screens=out.parent/'docs';meta=json.loads((pkg/'generated/assembly_manifest.json').read_text());expected=meta['initial_positions_rad'];result={};app=QApplication([])
robot=ET.parse(pkg/'generated/robot.urdf').getroot()
for j in robot.findall('joint'):
 m=j.find('mimic')
 if m is not None:expected[j.get('name')]=expected[m.get('joint')]*float(m.get('multiplier','1'))+float(m.get('offset','0'))
arm_meta=json.loads((Path(get_package_share_directory('rokae_ar5'))/'config/source_manifest.json').read_text())
rclpy.init();node=rclpy.create_node('asset_acceptance');state={};static={};dynamic={};description=[];seen={n:set() for n in expected}
def js(msg):
 state.update(zip(msg.name,msg.position))
 for n,p in zip(msg.name,msg.position):
  if n in seen:seen[n].add(round(p,9))
def tf_store(target,msg):
 for t in msg.transforms:target[t.child_frame_id]=t
subs=[node.create_subscription(JointState,'/joint_states',js,10),node.create_subscription(TFMessage,'/tf',lambda m:tf_store(dynamic,m),100),node.create_subscription(TFMessage,'/tf_static',lambda m:tf_store(static,m),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL,reliability=ReliabilityPolicy.RELIABLE)),node.create_subscription(String,'/robot_description',lambda m:description.append(m.data),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL,reliability=ReliabilityPolicy.RELIABLE))]
def wait(sec):
 end=time.monotonic()+sec
 while time.monotonic()<end:rclpy.spin_once(node,timeout_sec=.05);app.processEvents()
def pose(t):
 v=t.transform;m=np.eye(4);m[:3,:3]=Rotation.from_quat([v.rotation.x,v.rotation.y,v.rotation.z,v.rotation.w]).as_matrix();m[:3,3]=[v.translation.x,v.translation.y,v.translation.z];return m
def chain(name):
 if name=='base_link':return np.eye(4)
 t=(static|dynamic)[name];return chain(t.header.frame_id)@pose(t)
def check():
 assert set(state)==set(expected) and len(static)==43 and len(dynamic)==36,(len(state),len(static),len(dynamic))
 assert description and hashlib.sha256(description[-1].encode()).hexdigest()==meta['urdf_sha256']
 assert np.max(abs(chain('waist_mount')[:3,3]-[.108,0,.95]))<1e-8
 assert np.max(abs(chain('chest_link')[:3,:3]-np.array(arm_meta['chest_transform_mm'])[:3,:3]))<1e-8
 return dict(joint_states=36,static_transforms=43,dynamic_transforms=36,description_hash_matches=True,max_initial_joint_error_rad=max(abs(state[n]-expected[n]) for n in expected))
for mode in ['headless','gui']:
 state.clear();static.clear();dynamic.clear();description.clear();seen={n:set() for n in expected}
 env=os.environ.copy()
 if mode=='gui':env['PYTHONPATH']=str(args.output_package.resolve()/'test/gui_hook')+':'+env.get('PYTHONPATH','');env['ROKAE_GUI_PROBE']=str(screens)
 log=open('/tmp/rokae_hands_'+mode+'.log','w');proc=subprocess.Popen(['ros2','launch','robot_assembly_factory','display.launch.py','gui:='+str(mode=='gui').lower(),'rviz:='+str(mode=='gui').lower()],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  wait(6);assert proc.poll() is None;result[mode]=check();assert result[mode]['max_initial_joint_error_rad']<(1e-3 if mode=='gui' else 1e-10)
  if mode=='gui':
   wait(21);probe=json.loads((screens/'gui_events.json').read_text());assert probe['passed'],probe
   assert all(len(v)>=2 for v in seen.values()),{n:len(v) for n,v in seen.items()}
   result[mode]['sliders_operated']=26;result[mode]['observed_joint_changes']={n:len(v) for n,v in seen.items()}
   # Capture the actual external RViz window, not a rendered mockup.
   lines=subprocess.check_output(['xwininfo','-root','-tree'],text=True).splitlines();matches=[l for l in lines if 'rviz' in l.lower() and '0x' in l];assert matches,matches
   win=int(matches[0].strip().split()[0],16);assert app.primaryScreen().grabWindow(win).save(str(screens/'rviz2.png'))
   result[mode]['rviz_window_found']=True
   assert node.count_publishers('/joint_states')==1
   for j in robot.findall('joint'):
    m=j.find('mimic')
    if m is not None:assert abs(state[j.get('name')]-state[m.get('joint')]*float(m.get('multiplier'))-float(m.get('offset')))<1e-8
   result[mode]['mimic_relationships_verified']=10;result[mode]['joint_state_publishers']=1
  running_log=Path('/tmp/rokae_hands_'+mode+'.log').read_text()
 finally:
  proc.send_signal(signal.SIGINT)
  try:proc.wait(timeout=12)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  log.close();wait(.5)
 text=running_log;bad=[l for l in text.splitlines() if ('[ERROR]' in l or 'Could not load' in l or 'Error retrieving' in l or 'Traceback' in l) and 'Stereo' not in l];assert not bad,bad
result.update(passed=True,rviz_visual_inspection_required=True,installed_share=str(pkg),standalone_install=True,ROS_DISTRO=os.environ['ROS_DISTRO']);(out/'runtime_validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));node.destroy_node();rclpy.shutdown()
