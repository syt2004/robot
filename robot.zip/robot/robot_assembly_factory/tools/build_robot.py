#!/usr/bin/env python3
"""Build a robot from a hardware-agnostic assembly recipe (display only)."""
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import xml.etree.ElementTree as E
import yaml


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resolve_uri(uri, package_roots):
    if not uri.startswith('package://'):
        raise ValueError('Component source must use package://: ' + uri)
    owner, relative = uri[10:].split('/', 1)
    if Path(relative).is_absolute() or '..' in Path(relative).parts:
        raise ValueError('Invalid resource path: ' + uri)
    for base in package_roots:
        candidate = base if base.name == owner else base / owner
        if (candidate / 'package.xml').is_file():
            return candidate / relative
    matches = set()
    for base in package_roots:
        for directory, children, files in os.walk(base):
            children[:] = sorted(n for n in children if not n.startswith('.') and
                                 n not in ('build', 'install', 'log', '__pycache__'))
            if 'package.xml' in files:
                children[:] = []  # Model exports inside a package are resources, not packages.
                if E.parse(Path(directory) / 'package.xml').findtext('name') == owner:
                    matches.add(Path(directory).resolve())
    if len(matches) > 1:
        raise ValueError('Ambiguous package: ' + owner)
    if matches:
        return matches.pop() / relative
    from ament_index_python.packages import get_package_share_directory
    return Path(get_package_share_directory(owner)) / relative


def extract(source, spec):
    """Select a connected descendant subtree, rename only semantic URDF references."""
    links = {x.get('name'): x for x in source.findall('link')}
    joints = source.findall('joint')
    if spec['root'] not in links:
        raise ValueError('Missing component root: ' + spec['root'])
    excluded = set(spec.get('exclude_subtrees', []))
    if not excluded <= links.keys() or spec['root'] in excluded:
        raise ValueError('Invalid excluded subtree roots')
    names = {spec['root']}
    changed = True
    while changed:
        before = len(names)
        for joint in joints:
            parent = joint.find('parent').get('link')
            child = joint.find('child').get('link')
            if parent in names and child not in excluded:
                names.add(child)
        changed = len(names) != before
    selected = [copy.deepcopy(x) for x in source if
                x.tag == 'material' or x.tag == 'link' and x.get('name') in names or
                x.tag == 'joint' and x.find('parent').get('link') in names and
                x.find('child').get('link') in names]
    prefix = spec.get('prefix', '')
    for node in selected:
        if node.get('name'):
            node.set('name', prefix + node.get('name'))
        for elem in node.iter():
            if elem.tag in ('parent', 'child'):
                elem.set('link', prefix + elem.get('link'))
            elif elem.tag == 'mimic':
                elem.set('joint', prefix + elem.get('joint'))
            elif elem.tag == 'material' and elem is not node and elem.get('name'):
                elem.set('name', prefix + elem.get('name'))
    interfaces = {k: prefix + v for k, v in spec.get('interfaces', {}).items()}
    if not set(spec.get('interfaces', {}).values()) <= names:
        raise ValueError('Interface is outside selected subtree')
    return selected, prefix + spec['root'], interfaces


def validate_tree(root):
    links = [x.get('name') for x in root.findall('link')]
    joints = root.findall('joint')
    if len(set(links)) != len(links) or len({j.get('name') for j in joints}) != len(joints):
        raise ValueError('Duplicate link/joint names: use a component prefix')
    parents = {}
    byname = {j.get('name'): j for j in joints}
    for j in joints:
        if j.get('type') not in ('fixed', 'revolute', 'continuous', 'prismatic'):
            raise ValueError('Unsupported display joint type: ' + j.get('type', ''))
        p, c = (j.find(t).get('link') for t in ('parent', 'child'))
        if p not in links or c not in links or c in parents:
            raise ValueError('Invalid or multiply parented link: ' + c)
        parents[c] = p
        m = j.find('mimic')
        if m is not None and m.get('joint') not in byname:
            raise ValueError('Missing mimic driver: ' + m.get('joint'))
    roots = set(links) - parents.keys()
    if len(roots) != 1:
        raise ValueError('Assembly must have one root')
    for name in links:
        seen = set()
        while name in parents:
            if name in seen:
                raise ValueError('Joint graph cycle')
            seen.add(name)
            name = parents[name]
    return roots.pop()


def interval(joint):
    if joint.get('type') == 'continuous':
        lo, hi = -math.inf, math.inf
    else:
        lim = joint.find('limit')
        if lim is None:
            raise ValueError('Missing joint limit: ' + joint.get('name'))
        lo, hi = float(lim.get('lower')), float(lim.get('upper'))
        if not math.isfinite(lo) or not math.isfinite(hi) or lo > hi:
            raise ValueError('Invalid joint interval')
    soft = joint.find('safety_controller')
    if soft is not None:
        lo = max(lo, float(soft.get('soft_lower_limit', lo)))
        hi = min(hi, float(soft.get('soft_upper_limit', hi)))
    return lo, hi


def joint_defaults(root, explicit, guard_names):
    joints = {j.get('name'): j for j in root.findall('joint') if j.get('type') != 'fixed'}
    expressions = {}
    def expression(name, seen=()):
        if name in seen:
            raise ValueError('Mimic cycle')
        if name not in joints:
            raise ValueError('Mimic driver is not an active joint')
        if name in expressions:
            return expressions[name]
        m = joints[name].find('mimic')
        if m is None:
            result = (name, 1.0, 0.0)
        else:
            driver, k, b = expression(m.get('joint'), seen + (name,))
            mul, off = float(m.get('multiplier', 1)), float(m.get('offset', 0))
            if not math.isfinite(mul) or not math.isfinite(off):
                raise ValueError('Non-finite mimic coefficient')
            result = (driver, k * mul, b * mul + off)
        expressions[name] = result
        return result
    for name in joints:
        expression(name)
    drivers = {n: interval(j) for n, j in joints.items() if j.find('mimic') is None}
    bounds = {}
    for name in guard_names:
        if name not in joints:
            continue
        driver, k, b = expressions[name]
        lo, hi = interval(joints[name])
        if k == 0:
            if not lo <= b <= hi:
                raise ValueError('Constant mimic is outside limits')
            continue
        a, z = sorted(((lo-b)/k, (hi-b)/k))
        old = drivers[driver]
        drivers[driver] = (max(old[0], a), min(old[1], z))
        bounds[driver] = None
    for name in bounds:
        lo, hi = drivers[name]
        if lo > hi:
            raise ValueError('Empty mimic limit intersection: ' + name)
        if not math.isfinite(lo) or not math.isfinite(hi):
            continue
        j = joints[name]
        soft = j.find('safety_controller')
        if soft is None:
            soft = E.SubElement(j, 'safety_controller', k_position='0', k_velocity='0')
        soft.set('soft_lower_limit', str(lo)); soft.set('soft_upper_limit', str(hi))
        bounds[name] = {'lower_rad': lo, 'upper_rad': hi,
                        'reason': 'driver and recursive linear-mimic limit intersection'}
    if not explicit.keys() <= drivers.keys():
        raise ValueError('Initial positions contain absent or mimic joints: ' + str(explicit.keys()-drivers.keys()))
    values = {}
    for name, (lo, hi) in drivers.items():
        q = float(explicit.get(name, max(lo, min(hi, 0.0))))
        if not math.isfinite(q) or not lo <= q <= hi:
            raise ValueError('Initial position outside limits: ' + name)
        values[name] = q
    return values, {k:v for k,v in bounds.items() if v is not None}


def build_robot(recipe, output, package_roots):
    recipe, output = Path(recipe).resolve(), Path(output).resolve()
    settings = yaml.safe_load(recipe.read_text())
    if settings.get('schema') != 2:
        raise ValueError('Unsupported assembly recipe schema')
    root = E.Element('robot', name=settings['name'])
    pending = dict(settings['components']); done = {}; sources = {}; configs = {}
    explicit = {}; guards = set(); mounts = {}; materials = {}
    def remember(path):
        relative = path.resolve().relative_to(output)
        configs[str(relative)] = sha(path)
    remember(recipe)
    while pending:
        progress = False
        for slot, row in list(pending.items()):
            attach = row.get('attach')
            if attach and attach['parent'].split('.', 1)[0] not in done:
                continue
            descriptor = (recipe.parent / row['component']).resolve()
            remember(descriptor)
            spec = yaml.safe_load(descriptor.read_text())
            source_path = resolve_uri(spec['source'], package_roots)
            sources[spec['source'][10:]] = sha(source_path)
            source = E.parse(source_path).getroot()
            nodes, base, interfaces = extract(source, spec)
            for node in nodes:
                if node.tag == 'material':
                    name = node.get('name'); data = E.tostring(node).strip()
                    if name in materials:
                        if materials[name] != data:
                            raise ValueError('Conflicting global material: ' + name)
                        continue
                    materials[name] = data
                root.append(node)
            prefix = spec.get('prefix', '')
            explicit.update({prefix+k:v for k,v in spec.get('initial_positions', {}).items()})
            if spec.get('guard_mimic_limits', False):
                guards.update(n.get('name') for n in nodes if n.tag == 'joint' and n.get('type') != 'fixed')
            if attach:
                if 'origin_from_joint' in attach and any(k in attach for k in ('xyz_m','rpy_rad','mount')):
                    raise ValueError('Do not mix source joint and explicit mount transforms')
                owner, interface = attach['parent'].split('.', 1)
                parent = done[owner]['interfaces'][interface]
                j = E.SubElement(root, 'joint', name=attach.get('joint_name', slot+'_mount'), type='fixed')
                E.SubElement(j, 'parent', link=parent); E.SubElement(j, 'child', link=base)
                if 'origin_from_joint' in attach:
                    old = source.find("joint[@name='%s']" % attach['origin_from_joint'])
                    if old is None or old.get('type') != 'fixed':
                        raise ValueError('Mount origin source must be a fixed joint')
                    origin = copy.deepcopy(old.find('origin'))
                    if origin is None:
                        origin = E.Element('origin', xyz='0 0 0', rpy='0 0 0')
                else:
                    transform = attach
                    if 'mount' in attach:
                        path = recipe.parent / attach['mount']; remember(path)
                        transform = yaml.safe_load(path.read_text())[attach['transform_key']]
                    xyz, rpy = transform.get('xyz_m', [0,0,0]), transform.get('rpy_rad', [0,0,0])
                    if len(xyz) != 3 or len(rpy) != 3 or not all(math.isfinite(float(x)) for x in xyz+rpy):
                        raise ValueError('Mount must contain finite xyz/rpy triples')
                    origin = E.Element('origin', xyz=' '.join(map(str,xyz)), rpy=' '.join(map(str,rpy)))
                j.append(origin)
                mounts[slot] = {'parent':parent,'child':base,
                    'xyz_m':list(map(float,origin.get('xyz','0 0 0').split())),
                    'rpy_rad':list(map(float,origin.get('rpy','0 0 0').split()))}
            done[slot] = {'root':base, 'interfaces':interfaces, 'component':row['component'], 'source':spec['source']}
            del pending[slot]; progress = True
        if not progress:
            raise ValueError('Unresolved component attachment cycle or parent: ' + str(list(pending)))
    base = validate_tree(root)
    q, bounds = joint_defaults(root, explicit, guards)
    model_packages = {uri.split('/',1)[0] for uri in sources}
    for mesh in root.findall('.//mesh'):
        model_packages.add(mesh.get('filename')[10:].split('/',1)[0])
        path = resolve_uri(mesh.get('filename'), package_roots)
        if not path.is_file():
            raise ValueError('Missing mesh: ' + str(path))
    package_file = output/'package.xml'
    if package_file.exists():
        package = E.parse(package_file)
        previous = output/'generated/assembly_manifest.json'
        old = json.loads(previous.read_text()) if previous.exists() else {}
        previous_packages = set(old.get('model_dependencies', [])) | {u.split('/',1)[0] for u in old.get('source_urdf_sha256', {})}
        for dep in list(package.getroot().findall('exec_depend')):
            if dep.text in previous_packages:
                package.getroot().remove(dep)
        existing = {e.text for e in package.getroot().findall('exec_depend')}
        for owner in sorted(model_packages - existing):
            E.SubElement(package.getroot(), 'exec_depend').text = owner
        E.indent(package, space='  ')
        package.write(package_file, encoding='utf-8', xml_declaration=True)
    path = output/'generated/robot.urdf'; path.parent.mkdir(parents=True, exist_ok=True)
    E.indent(root, space='  '); E.ElementTree(root).write(path, encoding='utf-8', xml_declaration=True)
    (output/'generated').mkdir(exist_ok=True)
    (output/'generated/joint_state_publisher.yaml').write_text(yaml.safe_dump({'/**':{'ros__parameters':{'rate':30,'use_smallest_joint_limits':True,'zeros':q}}},sort_keys=False))
    meta = {'schema':3, 'recipe':str(recipe.relative_to(output)), 'configuration':settings['name'], 'components':done,
        'source_urdf_sha256':sources, 'config_sha256':configs, 'model_dependencies':sorted(model_packages),
        'component_mounts':mounts, 'root':base, 'link_count':len(root.findall('link')),
        'joint_count':len(root.findall('joint')), 'independent_joint_count':len(q),
        'hand_gui_bounds':bounds, 'initial_positions_rad':q, 'urdf_sha256':sha(path),
        'hardware_service_started':False, 'mechanical_adapter_verified':False,
        'coupling':'URDF linear mimic only; no hardware control or collision filtering'}
    (output/'generated/assembly_manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
    print(f"Built {settings['name']}: {meta['link_count']} links, {meta['joint_count']} joints, {len(q)} independent joints")
    return meta


def main():
    default = Path(__file__).resolve().parents[1]
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--recipe', type=Path, help='Assembly recipe (default: OUTPUT/config/assemblies/rokae_ar5_dh116s.yaml)')
    ap.add_argument('--package-root', action='append', type=Path, default=[], help='Package parent directory; repeatable; falls back to ament index')
    ap.add_argument('--output', type=Path, default=default)
    args = ap.parse_args()
    build_robot(args.recipe or args.output/'config/assemblies/rokae_ar5_dh116s.yaml',
                args.output, [p.resolve() for p in args.package_root])

if __name__ == '__main__':
    main()
