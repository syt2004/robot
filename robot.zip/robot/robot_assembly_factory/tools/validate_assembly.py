#!/usr/bin/env python3
from pathlib import Path
import argparse,copy,json,hashlib,math,xml.etree.ElementTree as E
import numpy as np
from scipy.spatial.transform import Rotation

def canon(e):return (e.tag,tuple(sorted(e.attrib.items())),tuple(canon(c) for c in e))
def fk(root,q):
 names={l.get('name') for l in root.findall('link')};children={j.find('child').get('link') for j in root.findall('joint')};base=(names-children).pop();frames={base:np.eye(4)};pending=root.findall('joint')
 while pending:
  rest=[]
  for j in pending:
   parent=j.find('parent').get('link')
   if parent not in frames:rest.append(j);continue
   t=np.eye(4);o=j.find('origin')
   if o is not None:t[:3,3]=np.fromstring(o.get('xyz','0 0 0'),sep=' ');t[:3,:3]=Rotation.from_euler('xyz',np.fromstring(o.get('rpy','0 0 0'),sep=' ')).as_matrix()
   if j.get('type')=='revolute':
    v=q.get(j.get('name'),0);m=j.find('mimic')
    if m is not None:v=q[m.get('joint')]*float(m.get('multiplier','1'))+float(m.get('offset','0'))
    t[:3,:3]=t[:3,:3]@Rotation.from_rotvec(np.fromstring(j.find('axis').get('xyz'),sep=' ')*v).as_matrix()
   frames[j.find('child').get('link')]=frames[parent]@t
  assert len(rest)<len(pending);pending=rest
 return frames

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source-root',type=Path,required=True);a=ap.parse_args();src=a.source_root.resolve();r=Path(__file__).resolve().parents[1];root=E.parse(r/'generated/robot.urdf').getroot();arm=E.parse(src/'rokae_ar5/description/urdf/rokae_ar5.urdf').getroot();meta=json.loads((r/'generated/assembly_manifest.json').read_text())
 for e in arm:
  new=root.find(f"{e.tag}[@name='{e.get('name')}']");assert new is not None and canon(e)==canon(new)
 rng=np.random.default_rng(2026);max_pos=max_rot=0.;hands={};source=src/'leadtron_lhand/hand_control_description'
 for side in ['left','right']:
  model='DH116S-'+('L' if side=='left' else 'R')+'000-A1'
  old=E.parse(source/'models'/model/'urdf'/(model+'.urdf')).getroot();hands[side]=old
  provenance=json.loads((source.parent/'UPSTREAM_MANIFEST.json').read_text())
  for path,digest in provenance['sha256'].items():
   if path.startswith('hand_control_description/models/'):
    assert hashlib.sha256((source.parent/path).read_bytes()).hexdigest()==digest,path
  for e in old:
   if e.tag not in ('link','joint'):continue
   new=copy.deepcopy(root.find(f"{e.tag}[@name='{side}_hand_{e.get('name')}']"));assert new is not None;new.set('name',e.get('name'))
   for tag in ['parent','child']:
    el=new.find(tag)
    if el is not None:el.set('link',el.get('link').removeprefix(side+'_hand_'))
   m=new.find('mimic')
   if m is not None:m.set('joint',m.get('joint').removeprefix(side+'_hand_'))
   guard=new.find('safety_controller')
   if guard is not None:new.remove(guard)
   expected=copy.deepcopy(e)
   for item in [new,expected]:
    for mesh in item.findall('.//mesh'):mesh.set('filename',Path(mesh.get('filename')).name)
    for material in item.findall('.//material'):material.set('name','')
   assert canon(new)==canon(expected),(side,e.get('name'))
 for sample in range(101):
  q=meta['initial_positions_rad'].copy()
  if sample:
   for name in q:
    j=root.find(f"joint[@name='{name}']");lim=j.find('safety_controller')
    if lim is None:lim=j.find('limit');lo=float(lim.get('lower'));hi=float(lim.get('upper'))
    else:lo=float(lim.get('soft_lower_limit'));hi=float(lim.get('soft_upper_limit'))
    q[name]=rng.uniform(lo,hi)
  poses=fk(root,q);arm_poses=fk(arm,q)
  for name,want in arm_poses.items():assert np.max(abs(poses[name]-want))<1e-12
  for side,hand in hands.items():
   hq={name.removeprefix(side+'_hand_'):value for name,value in q.items() if name.startswith(side+'_hand_')};local=fk(hand,hq);mount=meta['component_mounts'][side+'_hand'];j=root.find(f"joint[@name='{side}_hand_mount']");M=np.eye(4);M[:3,3]=mount['xyz_m'];M[:3,:3]=Rotation.from_euler('xyz',mount['rpy_rad']).as_matrix();base=poses[mount['parent']]@M
   for name,T in local.items():
    expected=base@T;actual=poses[side+'_hand_'+name];max_pos=max(max_pos,float(abs(actual[:3,3]-expected[:3,3]).max()));max_rot=max(max_rot,float(abs(actual[:3,:3]-expected[:3,:3]).max()))
   for j in hand.findall('joint'):
    m=j.find('mimic')
    if m is not None:v=hq[m.get('joint')]*float(m.get('multiplier'))+float(m.get('offset'));lim=j.find('limit');assert float(lim.get('lower'))-1e-10<=v<=float(lim.get('upper'))+1e-10
 assert max_pos<1e-5 and max_rot<1e-6
 result=dict(passed=True,seed=2026,configurations=101,arm_nodes_unchanged=True,vendor_hand_geometry_inertias_hard_limits_mimics_preserved=True,max_hand_FK_position_error_mm=max_pos*1000,max_hand_FK_rotation_error=max_rot,configured_mount_transforms_verified=True,physical_mount_calibration_verified=False,hand_source_files_unchanged=True,guarded_follower_limits_pass=True)
 (r/'config/validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
