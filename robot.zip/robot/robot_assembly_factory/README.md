# 机器人组装工厂

`robot_assembly_factory` 根据装配配方，从独立 ROS 2 硬件资产包中提取平台、机械臂和末端执行器，校验接口后生成一份可直接显示或供仿真读取的整机 URDF。

默认配方为 pedestal_01 底座 + chest_02 转接件 + AR5 左右臂 + DH116S 左右手。工厂自身不保存网格，也不启动真实硬件服务。

当前胸部使用 `chest_02.stl` 双臂转接件；旧 `chest_01.stl` 保留。安装坐标、预览及已构建的可视化命令见 [chest_02 说明](../rokae_ar5/description/docs/chest_02.md)。

## 目录职责

| 目录 | 内容 | 更换硬件时是否修改 |
|---|---|---|
| `config/components/` | 硬件适配器：来源 URDF、子树根、接口、前缀、初始关节角 | 新型号需要新增 |
| `config/assemblies/` | 机器人配方：槽位选型和连接关系 | 切换型号时修改或新增 |
| `config/mounts/` | 两种硬件之间的安装变换 | 更换法兰／转接件时新增 |
| `generated/` | 生成的 URDF、关节初值和输入哈希清单 | 由脚本更新，不手工编辑 |
| `tools/` | 构建与验证工具 | 通常不修改 |

这种划分让硬件型号不进入生成器代码。一个组件适配器可被多个机器人配方复用，同一硬件组合的不同转接件也可独立管理。

## 生成默认机器人

在仓库根目录运行：

```bash
python3 src/robot/robot_assembly_factory/tools/build_robot.py --package-root src/robot
```

生成器读取 `config/assemblies/rokae_ar5_dh116s.yaml`，写入：

- `generated/robot.urdf`
- `generated/joint_state_publisher.yaml`
- `generated/assembly_manifest.json`

构建并显示：

```bash
source /opt/ros/humble/setup.bash
colcon --log-base log/display build --base-paths src \
  --build-base build/display --install-base install \
  --packages-up-to robot_assembly_factory
./view_robot.sh
```

两个显示工具包的官方源码固定在 `src/third_party/joint_state_publisher`，上述构建会一并安装到当前工作空间；查看脚本只加载系统 ROS 和当前 `install/`。

无界面运行可追加 `gui:=false rviz:=false`。

## 替换硬件

1. 准备独立 ROS 2 资产包，URDF 中的网格使用 `package://` URI。
2. 在对应组件类别下新增 YAML，声明源 URDF、要提取的子树根和命名接口。
3. 如法兰变换不同，在 `config/mounts/` 新增安装参数。
4. 复制一个装配配方，替换目标槽位的 `component` 和 `mount`。
5. 用 `--recipe` 生成并运行测试。

```bash
python3 src/robot/robot_assembly_factory/tools/build_robot.py \
  --recipe src/robot/robot_assembly_factory/config/assemblies/my_robot.yaml \
  --package-root src/robot
python3 src/robot/robot_assembly_factory/test/test_factory.py
python3 src/robot/robot_assembly_factory/test/test_assets.py src/robot/robot_assembly_factory
```

组件字段和替换示例见 [硬件组件接口](docs/组件接口.md)。启动入口会核对配方、组件、安装参数、源 URDF 和生成 URDF 的哈希，避免误用过期产物。

更换实际硬件后仍需重新核对安装方向、机械干涉、关节限位和承载能力。默认 AR5 工具接口已包含 90 mm 法兰偏移；当前 DH116S 腕部只做坐标对齐，转接板厚度和孔系尚未确认。

手部直接引用官方 `leadtron_lhand/hand_control_description`，由组件配置添加左右前缀；嵌套集合通过 package.xml 包名解析，不依赖旧自维护描述包。详细职责见 [机器人描述设计](../../../docs/design_docs/robot_description_design.md)。

## DH116S 手心向下安装（2026-10-09）

以当前装配 init 关节姿态为准，修改 `config/mounts/ar5_dh116s.yaml` 中的固定安装变换：
左手绕法兰 Z 轴旋转 +90°，右手绕法兰 Z 轴旋转 −90°，平移保持为零。
官方手模型中左手掌心朝手基座 +Y，右手掌心朝 −Y；旋转后两侧掌心在
`base_link` 中约为 `[-0.087156, 0, -0.996195]`，均朝下。

当前 init 法兰带约 5° 倾角，因此保留该倾角，不额外倾斜法兰安装面或修改机械臂 init。
这是固定机械安装方向，不是运行时“始终保持掌心朝地”的姿态约束。
法兰仍作为 TCP，手部网格、官方关节限位和 mimic 不变。
实际转接件尺寸、孔系及安装标定仍需按实物核实。

## 当前模型的关节速度与加速度

左右机械臂的 URDF 速度上限相同：

| 关节 | 最大速度 rad/s | 最大速度 °/s |
|---|---:|---:|
| J1、J2 | 3.054326 | 175 |
| J3 | 4.712389 | 270 |
| J4 | 5.235988 | 300 |
| J5、J6、J7 | 4.188790 | 240 |

官方 DH116S URDF 的转动关节 `velocity` 均为 0，不能据此视为已提供可用于控制的硬件速度上限。
当前 WBC 仍固定双手 init；仿真手部速度来自独立驱动配置。
当前整机 URDF 没有最大加速度配置，WBC 也没有显式的关节加速度硬限制；
连续性与动能正则是软优化项，不等同于加速度上限。
WBC `custom_joint_speed_limits_rad_s.enabled` 开启时，双臂命令限速取 URDF 与 `joints` 中对应值的较小值；关闭时直接使用 URDF 速度上限。

配置读取约定：项目运行参数与 RViz 配置默认直接读取本工作区源码文件，修改后重启生效，无需重新构建，不支持热更新。源码树缺失时明确报错。可执行程序和 launch 代码变更仍需构建；装配配方、安装变换变更仍须重新生成并校验 URDF／碰撞资产，相关网格安装更新规则不变。
