"""Factory tests: replaceable hardware, reusable components, errors and limits."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as E
import yaml

spec = importlib.util.spec_from_file_location('factory', Path(__file__).parents[1]/'tools/build_robot.py')
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)

class RobotFactory(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name); self.out = self.root/'assembly'
        (self.out/'config/components/test').mkdir(parents=True)
        (self.out/'config/assemblies').mkdir(parents=True)
        (self.out/'package.xml').write_text('<package><name>assembly</name><exec_depend>robot_state_publisher</exec_depend></package>')
        self.assets = self.root/'alternative_assets'; self.assets.mkdir()
        (self.assets/'package.xml').write_text('<package><name>alternative_assets</name></package>')
        self.write('body', '<robot name="body"><link name="base_link"/><link name="shoulder"/><joint name="support" type="fixed"><parent link="base_link"/><child link="shoulder"/></joint></robot>')
        self.write('arm', '''<robot name="arm"><link name="base"/><link name="tool"/>
          <joint name="slide" type="prismatic"><parent link="base"/><child link="tool"/>
          <axis xyz="0 0 1"/><limit lower="0" upper="0.4" effort="5" velocity="1"/></joint></robot>''')
        self.write('hand', '''<robot name="hand"><material name="gray"><color rgba="0.5 0.5 0.5 1"/></material>
          <link name="palm"><visual><geometry><box size=".1 .1 .1"/></geometry><material name="gray"/></visual></link>
          <link name="a"/><link name="b"/><link name="c"/>
          <joint name="drive" type="revolute"><parent link="palm"/><child link="a"/><limit lower="0" upper="2" effort="1" velocity="1"/></joint>
          <joint name="follow" type="revolute"><parent link="a"/><child link="b"/><limit lower="0" upper="1" effort="1" velocity="1"/><mimic joint="drive" multiplier="-1" offset="1.5"/></joint>
          <joint name="nested" type="revolute"><parent link="b"/><child link="c"/><limit lower="0" upper="0.4" effort="1" velocity="1"/><mimic joint="follow" multiplier="0.5" offset="0"/></joint></robot>''')
        self.component('body', {'source':'package://alternative_assets/body.urdf','root':'base_link','interfaces':{'socket':'shoulder'}})
        self.component('arm', {'source':'package://alternative_assets/arm.urdf','root':'base','prefix':'arm_','interfaces':{'tool':'tool'}})
        self.component('hand', {'source':'package://alternative_assets/hand.urdf','root':'palm','prefix':'hand_','guard_mimic_limits':True})
        self.settings = {'schema':2,'name':'other_robot','components':{
            'body':{'component':'../components/test/body.yaml'},
            'arm':{'component':'../components/test/arm.yaml','attach':{'parent':'body.socket','xyz_m':[0,0,0.8]}},
            'hand':{'component':'../components/test/hand.yaml','attach':{'parent':'arm.tool','xyz_m':[0,0,0.02]}}}}
    def write(self, name, text):
        (self.assets/(name+'.urdf')).write_text(text)
    def component(self,name,data):
        (self.out/'config/components/test'/f'{name}.yaml').write_text(yaml.safe_dump(data))
    def run_factory(self):
        path = self.out/'config/assemblies/test_robot.yaml'; path.write_text(yaml.safe_dump(self.settings))
        return c.build_robot(path,self.out,[self.root])
    def test_replace_arm_and_hand_different_dof(self):
        result=self.run_factory()
        self.assertEqual(result['independent_joint_count'],2)
        self.assertEqual(result['component_mounts']['hand']['parent'],'arm_tool')
        self.assertAlmostEqual(result['hand_gui_bounds']['hand_drive']['lower_rad'],.7)
        self.assertAlmostEqual(result['hand_gui_bounds']['hand_drive']['upper_rad'],1.5)
        self.assertEqual(result['model_dependencies'],['alternative_assets'])
        r=E.parse(self.out/'generated/robot.urdf').getroot()
        self.assertEqual(r.find("joint[@name='hand_nested']/mimic").get('joint'),'hand_follow')
        self.assertEqual(r.find("link[@name='hand_palm']/visual/material").get('name'),'hand_gray')
        before=(self.out/'generated/robot.urdf').read_bytes();self.run_factory()
        self.assertEqual(before,(self.out/'generated/robot.urdf').read_bytes())
    def test_nested_package_collection(self):
        collection = self.root/'vendor'; collection.mkdir()
        self.assets = self.assets.rename(collection/self.assets.name)
        self.assertEqual(self.run_factory()['independent_joint_count'], 2)

    def test_fixed_gripper_and_no_hand(self):
        self.write('fixed','<robot name="fixed"><link name="plate"/></robot>')
        self.component('hand',{'source':'package://alternative_assets/fixed.urdf','root':'plate'})
        self.assertEqual(self.run_factory()['independent_joint_count'],1)
        del self.settings['components']['hand']
        self.assertEqual(self.run_factory()['independent_joint_count'],1)
    def test_same_hand_twice_with_prefix(self):
        self.component('right',{'source':'package://alternative_assets/hand.urdf','root':'palm','prefix':'right_','guard_mimic_limits':True})
        self.settings['components']['right']={'component':'../components/test/right.yaml','attach':{'parent':'arm.tool'}}
        self.assertEqual(self.run_factory()['independent_joint_count'],3)
    def test_duplicate_names_rejected(self):
        self.settings['components']['other']=copy.deepcopy(self.settings['components']['hand'])
        with self.assertRaisesRegex(ValueError,'Duplicate'):self.run_factory()
    def test_component_cycle_rejected(self):
        self.settings['components']['arm']['attach']['parent']='hand.tool'
        with self.assertRaisesRegex(ValueError,'cycle'):self.run_factory()
    def test_invalid_interface_rejected(self):
        self.component('arm',{'source':'package://alternative_assets/arm.urdf','root':'base','interfaces':{'tool':'absent'}})
        with self.assertRaisesRegex(ValueError,'Interface'):self.run_factory()
    def test_incompatible_mimic_rejected(self):
        p=self.assets/'hand.urdf';p.write_text(p.read_text().replace('offset="1.5"','offset="10"'))
        with self.assertRaisesRegex(ValueError,'Empty mimic'):self.run_factory()
    def test_mimic_cycle_rejected(self):
        p=self.assets/'hand.urdf';p.write_text(p.read_text().replace('joint="drive"','joint="nested"'))
        with self.assertRaisesRegex(ValueError,'Mimic cycle'):self.run_factory()
    def test_invalid_mount_rejected(self):
        self.settings['components']['hand']['attach']['xyz_m']=[float('nan'),0,0]
        with self.assertRaisesRegex(ValueError,'finite'):self.run_factory()
    def test_invalid_initial_rejected(self):
        self.component('arm',{'source':'package://alternative_assets/arm.urdf','root':'base','interfaces':{'tool':'tool'},'initial_positions':{'slide':3}})
        with self.assertRaisesRegex(ValueError,'outside limits'):self.run_factory()

if __name__=='__main__':unittest.main()
