"""Validate the generated assembly against its configuration, independent of model DOF."""
import sys,json,hashlib,xml.etree.ElementTree as E
from pathlib import Path
r=Path(sys.argv[1]);p=r/'generated/robot.urdf';root=E.parse(p).getroot();m=json.loads((r/'generated/assembly_manifest.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(p)==m['urdf_sha256']
for file,digest in m['config_sha256'].items():assert sha(r/file)==digest,file
links={e.get('name') for e in root.findall('link')};joints=root.findall('joint');byname={j.get('name'):j for j in joints};parents={j.find('child').get('link'):j.find('parent').get('link') for j in joints}
assert len(links)==m['link_count']==len(root.findall('link'))
assert len(joints)==len(byname)==len(parents)==m['joint_count']==len(links)-1
assert links-set(parents)=={m['root']}
for n in links:
 seen=set()
 while n!=m['root']:assert n not in seen;seen.add(n);n=parents[n]
active=[j for j in joints if j.get('type')!='fixed' and j.find('mimic') is None]
assert len(active)==m['independent_joint_count']
assert {j.get('name') for j in active}==m['initial_positions_rad'].keys()
for slot,mount in m['component_mounts'].items():
 matching=[j for j in joints if j.find('child').get('link')==mount['child']]
 assert len(matching)==1 and matching[0].get('type')=='fixed'
 assert matching[0].find('parent').get('link')==mount['parent']
assert {e.get('filename').split('/')[2] for e in root.findall('.//mesh')}<=set(m['model_dependencies'])
assert not (r/'meshes').exists()
print(f"PASS: {len(links)} links, {len(joints)} joints, {len(active)} independent joints; inputs and interfaces match")
