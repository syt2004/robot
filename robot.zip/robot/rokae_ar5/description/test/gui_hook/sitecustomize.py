import os,sys
if os.path.basename(sys.argv[0])=='joint_state_publisher_gui' and os.environ.get('ROKAE_GUI_PROBE'):
 import json,traceback
 from pathlib import Path
 from PyQt5.QtCore import QTimer,Qt
 from PyQt5.QtTest import QTest
 from joint_state_publisher_gui.joint_state_publisher_gui import JointStatePublisherGui
 old=JointStatePublisherGui.__init__
 def init(self,*args,**kwargs):
  old(self,*args,**kwargs);self.move(1510,100);self.resize(950,1150)
  self._probe_rows=[];self._probe_index=0
  def step():
   try:
    names=list(self.joint_map);assert len(names)==14
    idx=self._probe_index
    if idx>=28:
     self.grab().save(os.environ['ROKAE_GUI_PROBE']+'/joint_sliders.png')
     Path(os.environ['ROKAE_GUI_PROBE']+'/gui_events.json').write_text(json.dumps(dict(passed=True,sliders=14,events=self._probe_rows),indent=2));return
    name=names[idx//2];entry=self.joint_map[name];w=entry['slider'];self.scroll_area.ensureWidgetVisible(w);w.setFocus();before=entry['joint']['position'];QTest.keyClick(w,Qt.Key_Right if idx%2==0 else Qt.Key_Left);after=entry['joint']['position'];assert before!=after
    self._probe_rows.append(dict(joint=name,action='right' if idx%2==0 else 'left',before_rad=before,after_rad=after));self._probe_index+=1;QTimer.singleShot(250,step)
   except Exception:
    Path(os.environ['ROKAE_GUI_PROBE']+'/gui_events.json').write_text(json.dumps(dict(passed=False,error=traceback.format_exc())))
  QTimer.singleShot(8000,step)
 JointStatePublisherGui.__init__=init
