#!/usr/bin/env python3
"""Portable asset integrity test: Python standard library only."""
import hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path

def validate(root):
    robot=ET.parse(root/'urdf/rokae_ar5.urdf').getroot();links=robot.findall('link');joints=robot.findall('joint')
    names=[x.get('name') for x in links];assert len(names)==len(set(names))
    assert len({x.get('name') for x in joints})==len(joints)==len(links)-1
    active=[x for x in joints if x.get('type')=='revolute'];assert len(active)==14
    parents={j.find('child').get('link'):j.find('parent').get('link') for j in joints}
    assert len(parents)==len(joints) and set(names)-set(parents)=={'base_link'}
    for n in names:
        seen=set()
        while n!='base_link':assert n not in seen;seen.add(n);n=parents[n]
    for mesh in robot.findall('.//mesh'):
        uri=mesh.get('filename');assert uri.startswith('package://rokae_ar5/')
        rel=Path(uri.removeprefix('package://rokae_ar5/'));assert not rel.is_absolute() and '..' not in rel.parts
        path=root/rel;assert path.is_file() and not path.is_symlink()
    meta=json.loads((root/'config/source_manifest.json').read_text())
    for rel,row in meta['meshes'].items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==row['sha256']
    assert hashlib.sha256((root/'urdf/rokae_ar5.urdf').read_bytes()).hexdigest()==meta['urdf_sha256']
    assert {j.get('name') for j in active}==set(meta['initial_joint_positions_rad'])
    for j in active:
        lim=j.find('limit');q=meta['initial_joint_positions_rad'][j.get('name')];assert float(lim.get('lower'))<=q<=float(lim.get('upper'))
    assert meta['collision_policy'].startswith('Official original')
    if 'active_chest' in meta:
        chest=meta['active_chest']
        assert hashlib.sha256((root/chest['source']).read_bytes()).hexdigest()==chest['source_sha256']
        assert hashlib.sha256((root/chest['config']).read_bytes()).hexdigest()==chest['config_sha256']
        for mesh in robot.findall("link[@name='chest_link']/.//mesh"):
            assert mesh.get('filename')=='package://rokae_ar5/'+chest['mesh']
    if meta.get('active_pedestal', {}).get('version') == 'pedestal_01':
        selected=meta['active_pedestal']
        assert hashlib.sha256((root/selected['config']).read_bytes()).hexdigest()==selected['config_sha256']
        assert hashlib.sha256((root/selected['asset_config']).read_bytes()).hexdigest()==selected['asset_config_sha256']
        asset=json.loads((root/selected['asset_config']).read_text())
        assert hashlib.sha256((root/asset['source']).read_bytes()).hexdigest()==asset['source_sha256']
        assert {n for n in names if n.startswith('pedestal_')}=={'pedestal_01_link'}
        assert len(robot.findall("link[@name='pedestal_01_link']/collision"))==len(asset['collision_parts'])==19
        assert all('pedestal_02/' not in m.get('filename') for m in robot.findall('.//mesh'))
        mount=robot.find("joint[@name='waist_mount_fixed']/origin")
        assert list(map(float,mount.get('xyz').split()))==[0,0,.856]
        assert list(map(float,mount.get('rpy').split()))==[0,0,0]
    print(f"PASS: one root,{len(links)} links,{len(joints)} joints,14 active joints; all {len(meta['meshes'])} mesh hashes and URDF verified")
if __name__=='__main__':validate(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
