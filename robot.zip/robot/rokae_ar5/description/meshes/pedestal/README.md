# 底座版本

| 版本 | 文件 | 来源与用途 |
|---|---|---|
| `pedestal_01` | [源 STP](pedestal_01/pedestal_01.stp)、[米制 STL](pedestal_01/pedestal_01.stl) | 仓库根目录 `双臂机器人支架.stp`，当前整机使用的底座。 |
| `pedestal_02` | `pedestal_02/` 下的 25 个 STL | 保留备用的 R04 前倾底座；仅移动目录，保留原网格字节、颜色、link 名称及安装变换。 |

当前整机 URDF 引用 `pedestal_01/`。其中 `01_splayed_four_fork_baseplate.stl`、`02_caster_00.stl` 等文件名前的数字是**零件编号**，不是底座版本号。保留分件网格可以继续使用原来的局部坐标与颜色，避免将多零件装配误当成一个局部网格。

## pedestal_01 坐标与追溯

包内 STP 基于用户提供的原文件修改，仓库根目录原文件保持不变。2026-10-07 将顶端圆盘外径从 **200 mm 改为 240 mm**，厚度仍为 **16 mm**；孔系按 `chest_02` 底部法兰调整为 **6 × Ø13 mm 通孔、Ø210 mm 分布圆**（原为 Ø10.3 mm 孔、Ø170 mm 分布圆），保留两端 **0.85 mm × 45°** 倒角。修改仅涉及立柱实体（`parts/part_17.stl`）的顶端圆盘，其余 18 个实体及下部立柱几何不变。模型含 19 个有效实体，CAD 外形约为 **800 × 800 × 856 mm**。导出保持 CAD 轴向，减去源包围盒底面中心后由毫米转换为米：

```text
mesh_xyz_m = (source_xyz_mm - [-3179.12831529154, 44.264818508337015, 883.9999999000071]) / 1000
```

CAD 顶面中心为 `(-3179.12831529154, 44.264818508337015, 1740)` mm，法线为 +Z；转换后安装点为 `(0,0,0.856)` m。当前 `waist_mount_fixed` 使用该位置，rpy 为零；`chest_mount_fixed` 沿用绕 Z 轴 90° 的左右朝向。旧底座的 108 mm 前移和 30° 前倾不再使用。实物孔位、安装转角仍待核实，未假设材料密度或惯量。

按上述装配变换，顶盘孔中心相对顶盘圆心的 XY 坐标为 `(0, ±105)`、`(±90.932667, ±52.5)` mm（后者取四种符号组合）。已从 `chest_02.STEP` 提取底部孔轴线并转换到同一坐标系，验证 6 组孔中心及孔径一致、轴线平行，中心偏差小于 `1e-6 mm`；CAD 布尔校验确认旧孔已填实、新孔贯通，安装高度与盘厚不变。此结果是 CAD 孔系对齐校验，不替代实物装配标定。

可视化使用完整 STL；碰撞几何使用 `parts/` 下的 19 个实体网格，避免将整个底座合成一个凸包后填满立柱周围的空隙。分件凸包仍不代表精确孔洞或凹面碰撞。

导出参数、源文件和网格哈希、边界记录在 [pedestal_01.json](../../config/pedestal_01.json)。STL 为 566,720 个三角形；线性离散容差为 0.1 mm，角度容差为 0.08 rad。

从仓库根目录重新导出当前版本：

```bash
env -u PYTHONPATH uv run --no-project --with cadquery==2.7.0 --with scipy \
  python src/robot/rokae_ar5/description/tools/export_pedestal.py
python3 src/robot/rokae_ar5/description/tools/apply_pedestal.py
python3 src/robot/robot_assembly_factory/tools/build_robot.py --package-root src/robot
```

选择和安装参数在 [active_pedestal.json](../../config/active_pedestal.json)。`export_pedestal.py` 更新网格及来源记录，`apply_pedestal.py` 应用到源 URDF，再由工厂生成整机。完整 R04 导出器仍保留 `pedestal_02/` 资产，但最后会应用当前选择，避免重新导出时退回旧底座。

## 查看当前整机

```bash
./view_robot.sh
```

当前显示组合为 **`pedestal_01` + `chest_02`**。修改整机资产后需重新生成组装结果并构建，参见 [chest_02 查看与构建说明](../../docs/chest_02.md)。
