# chest_02 双臂转接件

当前整机使用 `chest_02.stl`。当前来源为仓库根目录的 `双臂转接件 2个 白色 .STEP`（2026-10-07 修正），原文件保留，并按原字节复制到包内 `meshes/chest/chest_02.STEP`；旧网格 `chest_01.stl` 保留，但不再用于当前 URDF。包内 STEP、STL 和导出配置的哈希记录在 `config/source_manifest.json`。

底座版本独立管理：当前使用 `pedestal_01`，`pedestal_02` 保留为备用资产，见 [底座版本说明](../meshes/pedestal/README.md)。

## 坐标与装配

STEP 声明毫米单位，包含 5 个有效实体。源几何包围盒为 X=[-120,120]、Y=[-16,238]、Z=[-120,120] mm。底部法兰厚 16 mm，两侧法兰外表面位于 CAD Z=±112 mm，圆心 CAD Y=180 mm。

以底部安装面中心 `(0,-16,0)` mm 为 `chest_link` 原点，转换为米：

```text
x_link = z_CAD / 1000
y_link = x_CAD / 1000
z_link = (y_CAD + 16) / 1000
```

该变换为右手旋转，不是镜像。输出网格范围约为 X=[-0.120,0.120]、Y=[-0.120,0.120]、Z=[0,0.254] m，URDF mesh scale 为 `1 1 1`。

| 安装关节 | chest_link 下 xyz（m） | rpy（rad） |
|---|---|---|
| left_shoulder_mount | `0.112 0 0.196` | `0 π/2 0` |
| right_shoulder_mount | `-0.112 0 0.196` | `0 -π/2 0` |

机械臂根的 +Z 轴分别朝两侧法兰外法线。底座至胸部使用 pedestal_01 水平顶面中心 `(0,0,0.856)` m，不再前倾或前移；胸部绕自身 Z 轴 90°，两臂轴向转角沿用旧值；这些是用于查看的装配约定，实物安装尚未标定。

当前 CAD 两侧法兰外径 **116 mm**、厚度 **12 mm**，安装面间距 **224 mm**；侧面小孔直径 **3.3 mm**，孔中心位于直径 **105 mm** 的分布圆上。底部法兰仍为外径 240 mm、厚度 16 mm，不能与侧法兰混淆。当前按侧法兰圆心及法线定位两臂；实际孔位角度、紧固件与安装转角仍需核对，未据外径接近就宣称实物安装已验证，也未虚构材料密度或惯量。

## 可视化

已构建的工作空间可直接运行：

```bash
cd /home/wangyunlong/workspace/rokae_robot_assets
./view_robot.sh
```

脚本通过当前工作空间 `install/setup.bash` 加载构建时记录的 ROS 环境和工作空间包。`joint_state_publisher` 与 `joint_state_publisher_gui` 从仓库 `src/third_party/joint_state_publisher` 构建到当前 `install/`，不再加载带有旧机器人模型的个人依赖目录。该入口只启动模型、关节滑块和 RViz，不启动硬件驱动。无需滑块时添加 `gui:=false`；无图形检查使用 `gui:=false rviz:=false`。

![chest_02 整机预览](chest_02_assembly.png)

使用 `build/display` 避免既有构建目录保留旧包路径缓存，统一安装到默认 `install/`。此前的 `install/chest_02` 不再作为推荐入口。重新构建：

```bash
source /opt/ros/humble/setup.bash
colcon --log-base log/display build \
  --base-paths src/robot/rokae_ar5 src/robot/robot_assembly_factory \
    src/robot/leadtron_lhand/hand_control_description \
    src/robot/leadtron_lhand/hand_control_interfaces \
    src/third_party/joint_state_publisher \
  --build-base build/display --install-base install \
  --packages-up-to robot_assembly_factory
```

## 离线重新导出

安装参数在 `config/chest_02.json`，CAD 依赖仅用于导出，不加入 ROS 运行依赖。从仓库根目录运行：

```bash
uv run --no-project --with cadquery==2.7.0 --with scipy python -I \
  src/robot/rokae_ar5/description/tools/export_chest.py
python3 src/robot/robot_assembly_factory/tools/build_robot.py --package-root src/robot
```

导出器更新 chest 的 visual／collision、两侧固定安装关节及源资产清单；完整旧 CAD 导出器也会在存在 `chest_02.json` 时应用新件，避免再次生成时退回旧胸部。软件版本记录于源清单。改动几何／坐标后应重新校验并构建，不能只复制旧报告。

Newton 的交叉臂胶囊不包含胸部，胸部与底座更换均已核对双臂双手的局部网格、关节和 fixed-body 排除关系未改变，保留胶囊参数并更新来源哈希。该结果不代表新的全身碰撞或回位路径已验证；旧版本录制数据的模型哈希也不能改写成新模型。

## 本次验证

- 包内 STEP 与原文件 SHA-256 一致；STL 包含 5 个封闭实体、26,132 个三角形，毫米到米的边界误差在 0.1 mm 网格容差内。
- 源模型与整机结构／资源哈希通过；101 组姿态的整机 FK 对比通过。
- Newton 资产加载、胶囊覆盖校验及 FK／增量 IK 两项回归通过。
- 四个 ROS 包构建通过；已安装的 display launch 无图形启动成功，收到 36 个关节（26 主动＋10 mimic）的状态，robot_description 引用 chest_02。
- 几何及验证结果见 `config/chest_02_validation.json`。未连接硬件，也未验证实物孔系、强度或长期动力学。
