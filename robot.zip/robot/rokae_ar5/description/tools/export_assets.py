#!/usr/bin/env python3
"""Offline CAD exporter. CAD/numpy/scipy are export-only, never runtime dependencies."""
import argparse,copy,hashlib,json,math,struct,xml.etree.ElementTree as ET
from pathlib import Path
import cadquery as cq
import numpy as np
from scipy.spatial.transform import Rotation
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def nums(v):return ' '.join(f'{float(x):.16g}' for x in v)
def stl(shape,path,offset):
    vv,tt=shape.tessellate(.1,.08);v=(np.array([p.toTuple() for p in vv])-offset)/1000;t=np.array(tt)
    n=np.cross(v[t[:,1]]-v[t[:,0]],v[t[:,2]]-v[t[:,0]]);n/=np.maximum(np.linalg.norm(n,axis=1)[:,None],1e-30)
    with path.open('wb') as f:
        f.write(b'Rokae CAD mesh, metres'.ljust(80,b'\0'));f.write(struct.pack('<I',len(t)))
        for normal,tri in zip(n,v[t]):f.write(struct.pack('<12fH',*normal,*tri.flatten(),0))
    return dict(vertices=len(v),triangles=len(t),mesh_bounds_m=[v.min(axis=0).tolist(),v.max(axis=0).tolist()])
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source-root',type=Path,required=True);ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]);args=ap.parse_args()
    src=args.source_root.resolve();out=args.output.resolve();review=src/'升降前倾底座_评审版'
    p=json.loads((review/'parameters.json').read_text());report=json.loads((review/'robot_integration_validation.json').read_text());manifest=json.loads((review/'parts_manifest.json').read_text())
    assert p['tilt_deg']==30 and p['pedestal_overall_height_mm']==1000 and p['fixed_waist_height_mm']==950
    for d in ['urdf','meshes/pedestal/pedestal_02','meshes/chest','meshes/left','meshes/right','config']: (out/d).mkdir(parents=True,exist_ok=True)
    robot=ET.Element('robot',name='rokae_ar5');ET.SubElement(robot,'link',name='base_link')
    sources={};mapping={};meshes={};centres={};boxes=[];initial={}
    def source(path):sources[str(path.relative_to(src))]=digest(path)
    for file in ['parameters.json','robot_integration_validation.json','parts_manifest.json','validation.json']:source(review/file)
    def fixed(name,parent,child,xyz=(0,0,0),rpy=(0,0,0)):
        j=ET.SubElement(robot,'joint',name=name,type='fixed');ET.SubElement(j,'parent',link=parent);ET.SubElement(j,'child',link=child);ET.SubElement(j,'origin',xyz=nums(xyz),rpy=nums(rpy))
    def cad_link(name,shape,path,offset,color):
        link=ET.SubElement(robot,'link',name=name);meshes[path]=stl(shape,out/path,np.array(offset));meshes[path]['sha256']=digest(out/path)
        for typ in ['visual','collision']:
            el=ET.SubElement(link,typ);ET.SubElement(el,'origin',xyz='0 0 0',rpy='0 0 0');g=ET.SubElement(el,'geometry');ET.SubElement(g,'mesh',filename='package://rokae_ar5/'+path,scale='1 1 1')
            if typ=='visual':ET.SubElement(ET.SubElement(el,'material',name=name+'_material'),'color',rgba=nums([int(color[i:i+2],16)/255 for i in (1,3,5)]+[1]))
    for item in manifest:
        if item['name']=='30_original_chest_support':continue
        path=review/'STEP/parts'/(item['name']+'.step');source(path);shape=cq.importers.importStep(str(path)).val();assert shape.isValid()
        bb=Bnd_Box();BRepBndLib.AddOptimal_s(shape.wrapped,bb,False,False);boxes.append(bb.Get())
        centre=np.array(shape.Center().toTuple());name='pedestal_'+item['name'];cad_link(name,shape,'meshes/pedestal/pedestal_02/'+item['name']+'.stl',centre,item['color']);fixed(name+'_fixed','base_link',name,centre/1000)
        mapping[item['name']]=name;centres[name]=centre.tolist()
    ET.SubElement(robot,'link',name='waist_mount');fixed('waist_mount_fixed','base_link','waist_mount',[p['waist_forward_offset_mm']/1000,0,p['fixed_waist_height_mm']/1000],[0,math.radians(p['tilt_deg']),0])
    path=src/report['chest_source'];source(path);chest=cq.importers.importStep(str(path)).val();cad_link('chest_link',chest,'meshes/chest/chest_01.stl',[0,0,0],'#a6b2bd');fixed('chest_mount_fixed','waist_mount','chest_link',rpy=[0,0,math.radians(p['chest_clock_deg'])]);mapping['30_original_chest_support']='chest_link'
    expected=np.eye(4);expected[:3,:3]=Rotation.from_euler('y',p['tilt_deg'],degrees=True).as_matrix()@Rotation.from_euler('z',p['chest_clock_deg'],degrees=True).as_matrix();expected[:3,3]=[p['waist_forward_offset_mm'],0,p['fixed_waist_height_mm']]
    assert np.max(abs(expected-np.array(report['chest_transform_mm'])))<1e-8
    materials={}
    for side,sign in [('left',1),('right',-1)]:
        path=src/report['arms'][side]['urdf'];source(path);original=ET.parse(path).getroot();base=original.find("joint[@name='fixed']/child").get('link')
        for mat in original.findall('material'):
            key=mat.get('name');data=ET.tostring(mat)
            if key in materials:assert materials[key]==data
            else:materials[key]=data;robot.append(copy.deepcopy(mat))
        for link in original.findall('link'):
            if link.get('name')=='world':continue
            link=copy.deepcopy(link)
            for mesh in link.findall('.//mesh'):
                old=path.parent.parent/'meshes'/Path(mesh.get('filename')).name;source(old);rel='meshes/'+side+'/'+old.name;(out/rel).write_bytes(old.read_bytes());mesh.set('filename','package://rokae_ar5/'+rel);meshes[rel]=dict(sha256=digest(old),source=str(old.relative_to(src)),original_bytes=True)
            robot.append(link)
        for joint in original.findall('joint'):
            if joint.find('parent').get('link')=='world':continue
            robot.append(copy.deepcopy(joint))
            if joint.get('type')=='revolute':initial[joint.get('name')]=math.radians(p['arm_joint_degrees'][side][int(joint.get('name').rsplit('_',1)[1])-1])
        fixed(side+'_shoulder_mount','chest_link',base,[sign*.022,0,.263849899658645],[0,sign*math.pi/2,0])
    ET.indent(robot,space='  ');ET.ElementTree(robot).write(out/'urdf/rokae_ar5.urdf',encoding='utf-8',xml_declaration=True)
    # Nested ROS parameters initialize both GUI and headless publishers identically.
    import yaml
    (out/'config/joint_state_publisher.yaml').write_text(yaml.safe_dump({'/**':{'ros__parameters':{'rate':30,'zeros':initial}}},sort_keys=False))
    meta=dict(revision='R04',configuration=p,root_frame='base_link',length_unit='m',angle_unit='rad',collision_policy='Official original arm meshes; no collision filtering in this visualization package',sources_sha256=sources,cad_to_link=mapping,cad_link_centres_mm=centres,meshes=meshes,initial_joint_positions_rad=initial,chest_transform_mm=expected.tolist(),pedestal_exact_bounds_mm=[min(b[0] for b in boxes),min(b[1] for b in boxes),min(b[2] for b in boxes),max(b[3] for b in boxes),max(b[4] for b in boxes),max(b[5] for b in boxes)],inertia_policy='Original arm inertias retained; no invented inertia for pedestal or chest',urdf_sha256=digest(out/'urdf/rokae_ar5.urdf'))
    meta['active_pedestal'] = dict(version='pedestal_02', mesh_directory='meshes/pedestal/pedestal_02', geometry_and_mounts_unchanged=True)
    assert len(initial)==14 and len(mapping)==26
    assert abs(meta['pedestal_exact_bounds_mm'][5]-1000)<1e-4
    for name,h in sources.items():assert digest(src/name)==h
    (out/'config/source_manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
    if (out/'config/chest_02.json').exists():
        from export_chest import export_chest
        export_chest(out)
    if (out/'config/active_pedestal.json').exists():
        from apply_pedestal import apply_pedestal
        apply_pedestal(out)
    print('Exported',len(robot.findall('link')),'links;',len(robot.findall('joint')),'joints;',len(meshes),'self-contained meshes')
if __name__=='__main__':main()
