#!/usr/bin/env python3
"""Export the alternate pedestal CAD to metres; do not change the active URDF."""
import argparse
import hashlib
import json
from pathlib import Path

import cadquery as cq
import numpy as np
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box

from export_assets import stl


def export_pedestal(package):
    source = package / 'meshes/pedestal/pedestal_01/pedestal_01.stp'
    mesh = source.with_suffix('.stl')
    shape = cq.importers.importStep(str(source)).val()
    if not shape.isValid() or not shape.Solids():
        raise ValueError('Invalid or empty pedestal CAD')
    box = Bnd_Box()
    BRepBndLib.AddOptimal_s(shape.wrapped, box, False, False)
    bounds = np.array(box.Get())
    # Retain CAD axes; remove its remote assembly offset and put the floor at Z=0.
    offset = np.array([(bounds[0] + bounds[3]) / 2,
                       (bounds[1] + bounds[4]) / 2, bounds[2]])
    info = stl(shape, mesh, offset)
    parts = []
    parts_dir = source.parent / 'parts'
    parts_dir.mkdir(exist_ok=True)
    for index, solid in enumerate(shape.Solids()):
        part = parts_dir / f'part_{index:02d}.stl'
        part_info = stl(solid, part, offset)
        parts.append({'mesh': str(part.relative_to(package)),
                      'sha256': hashlib.sha256(part.read_bytes()).hexdigest(), **part_info})
    report = {
        'version': 'pedestal_01',
        'original_source_name': '双臂机器人支架.stp',
        'source': str(source.relative_to(package)),
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'mesh': str(mesh.relative_to(package)),
        'mesh_sha256': hashlib.sha256(mesh.read_bytes()).hexdigest(),
        'source_unit': 'mm', 'mesh_unit': 'm',
        'source_bounds_mm': bounds.tolist(), 'source_origin_mm': offset.tolist(),
        'source_to_mesh_rotation': np.eye(3, dtype=int).tolist(),
        'solid_count': len(shape.Solids()), 'cadquery_version': cq.__version__,
        'linear_tolerance_mm': 0.1, 'angular_tolerance_rad': 0.08,
        'mount_calibration_verified': False,
        'inertia_policy': 'No assumed density or inertia', 'collision_parts': parts, **info,
    }
    (package / 'config/pedestal_01.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, default=Path(__file__).resolve().parents[1])
    export_pedestal(parser.parse_args().package.resolve())
