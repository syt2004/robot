#!/usr/bin/env python3
"""Apply the selected pedestal and its CAD mounting frame to the source URDF."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def numbers(values):
    return ' '.join(f'{float(v):.16g}' for v in values)


def apply_pedestal(package):
    config_path = package / 'config/active_pedestal.json'
    selection = json.loads(config_path.read_text())
    if selection['version'] != 'pedestal_01':
        raise ValueError('This adapter supports pedestal_01; R04 is exported by export_assets.py')
    asset_path = package / selection['asset_config']
    asset = json.loads(asset_path.read_text())
    for rel, digest in [(asset['source'], asset['source_sha256']),
                        (asset['mesh'], asset['mesh_sha256']),
                        *((p['mesh'], p['sha256']) for p in asset['collision_parts'])]:
        if sha(package / rel) != digest:
            raise ValueError(f'Pedestal asset changed: {rel}; run export_pedestal.py')
    path = package / 'urdf/rokae_ar5.urdf'
    tree = ET.parse(path)
    root = tree.getroot()
    old_links = {n.get('name') for n in root.findall('link') if n.get('name').startswith('pedestal_')}
    for node in list(root):
        if ((node.tag == 'link' and node.get('name') in old_links) or
                (node.tag == 'joint' and node.find('child').get('link') in old_links)):
            root.remove(node)
    link = ET.SubElement(root, 'link', name='pedestal_01_link')
    visual = ET.SubElement(link, 'visual')
    ET.SubElement(ET.SubElement(visual, 'geometry'), 'mesh',
                  filename='package://rokae_ar5/' + asset['mesh'], scale='1 1 1')
    ET.SubElement(ET.SubElement(visual, 'material', name='pedestal_material'),
                  'color', rgba='0.65 0.67 0.72 1')
    # Separate CAD solids avoid a single convex hull filling the space around the column.
    for part in asset['collision_parts']:
        collision = ET.SubElement(link, 'collision')
        ET.SubElement(ET.SubElement(collision, 'geometry'), 'mesh',
                      filename='package://rokae_ar5/' + part['mesh'], scale='1 1 1')
    joint = ET.SubElement(root, 'joint', name='pedestal_01_fixed', type='fixed')
    ET.SubElement(joint, 'parent', link='base_link')
    ET.SubElement(joint, 'child', link='pedestal_01_link')
    ET.SubElement(joint, 'origin', xyz='0 0 0', rpy='0 0 0')
    origin = root.find("joint[@name='waist_mount_fixed']/origin")
    origin.set('xyz', numbers(selection['waist_xyz_m']))
    origin.set('rpy', numbers(selection['waist_rpy_rad']))
    origin = root.find("joint[@name='chest_mount_fixed']/origin")
    origin.set('rpy', numbers(selection['chest_rpy_rad']))
    ET.indent(tree, space='  ')
    tree.write(path, encoding='utf-8', xml_declaration=True)
    meta_path = package / 'config/source_manifest.json'
    meta = json.loads(meta_path.read_text())
    if 'legacy_r04' not in meta:
        meta['legacy_r04'] = copy.deepcopy({k: meta[k] for k in ('revision', 'configuration', 'sources_sha256')})
    meta['revision'] = 'pedestal_01_chest_02'
    meta['active_pedestal'] = {**selection, 'config': str(config_path.relative_to(package)),
                              'config_sha256': sha(config_path), 'asset_config_sha256': sha(asset_path)}
    meta['configuration'].update(pedestal_overall_height_mm=856, fixed_waist_height_mm=856,
                                 waist_forward_offset_mm=0, tilt_deg=0)
    meta['pedestal_exact_bounds_mm'] = [-400, -400, 0, 400, 400, 856]
    meta['chest_transform_mm'] = [[0, -1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 856], [0, 0, 0, 1]]
    meta['cad_to_link'] = {k: v for k, v in meta['cad_to_link'].items() if v not in old_links}
    meta['cad_to_link']['pedestal_01'] = 'pedestal_01_link'
    meta['cad_link_centres_mm'] = {'pedestal_01_link': asset['source_origin_mm']}
    meta['meshes'] = {k: v for k, v in meta['meshes'].items() if not k.startswith('meshes/pedestal/')}
    meta['meshes'][asset['mesh']] = {'sha256': asset['mesh_sha256']}
    for part in asset['collision_parts']:
        meta['meshes'][part['mesh']] = {k: v for k, v in part.items() if k != 'mesh'}
    meta['urdf_sha256'] = sha(path)
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n')
    print('Applied pedestal_01 + chest_02, waist at 0 0 0.856 m, no forward tilt')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, default=Path(__file__).resolve().parents[1])
    apply_pedestal(parser.parse_args().package.resolve())
