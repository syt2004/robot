#!/usr/bin/env python3
"""Export the selected chest STEP and update its URDF mounts and provenance.

Requires CadQuery/numpy/scipy only for offline export, not ROS visualization.
The original chest_01 mesh and upstream STEP are retained.
"""
import argparse
import hashlib
import json
import struct
import xml.etree.ElementTree as ET
from pathlib import Path

import cadquery as cq
import numpy as np
from scipy.spatial.transform import Rotation


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def numbers(values):
    return ' '.join(f'{float(value):.16g}' for value in values)


def export_chest(package):
    package = Path(package).resolve()
    config_path = package / 'config/chest_02.json'
    config = json.loads(config_path.read_text())
    source = package / config['source']
    output = package / config['mesh']
    if config['source_unit'] != 'mm' or config['mesh_unit'] != 'm':
        raise ValueError('This CAD export requires millimetres to metres')
    rotation = np.asarray(config['source_to_link_rotation'], dtype=float)
    offset = np.asarray(config['source_origin_mm'], dtype=float)
    if not (np.allclose(rotation @ rotation.T, np.eye(3)) and
            np.isclose(np.linalg.det(rotation), 1.0)):
        raise ValueError('Expected a proper source-to-link rotation')
    shape = cq.importers.importStep(str(source)).val()
    if not shape.isValid() or not shape.Solids():
        raise ValueError('Invalid or empty STEP solid geometry')
    vertices, faces = shape.tessellate(config['linear_tolerance_mm'],
                                      config['angular_tolerance_rad'])
    source_vertices = np.asarray([v.toTuple() for v in vertices])
    points = ((source_vertices - offset) @ rotation.T) / 1000.0
    triangles = points[np.asarray(faces)]
    normals = np.cross(triangles[:, 1] - triangles[:, 0],
                       triangles[:, 2] - triangles[:, 0])
    lengths = np.linalg.norm(normals, axis=1)
    valid = lengths > 1e-18
    if not np.isfinite(points).all() or not valid.all():
        raise ValueError('Non-finite or degenerate tessellation')
    normals /= lengths[:, None]
    # Validate mount directions before changing runtime assets.
    mounts = {}
    for name, mount in config['mounts'].items():
        normal = rotation @ np.asarray(mount['source_outward_normal'])
        if not np.allclose(Rotation.from_euler('xyz', mount['rpy_rad']).apply([0, 0, 1]), normal):
            raise ValueError(f'Arm base axis does not match flange normal: {name}')
        mounts[name] = (rotation @ (np.asarray(mount['source_center_mm']) - offset)) / 1000.0
    tree = ET.parse(package / 'urdf/rokae_ar5.urdf')
    root = tree.getroot()
    chest = root.find("link[@name='chest_link']")
    if chest is None:
        raise ValueError('Missing chest_link')
    for name in mounts:
        if root.find(f"joint[@name='{name}']/origin") is None:
            raise ValueError(f'Missing mount {name}')
    with output.open('wb') as stream:
        stream.write(b'Chest 02: STEP mm to chest_link metres'.ljust(80, b'\0'))
        stream.write(struct.pack('<I', len(triangles)))
        for normal, triangle in zip(normals, triangles):
            stream.write(struct.pack('<12fH', *normal, *triangle.flatten(), 0))
    for kind in ('visual', 'collision'):
        node = chest.find(kind)
        node.find('geometry/mesh').set('filename', 'package://rokae_ar5/' + config['mesh'])
        node.find('geometry/mesh').set('scale', '1 1 1')
        node.find('origin').set('xyz', '0 0 0')
        node.find('origin').set('rpy', '0 0 0')
    chest.find('visual/material/color').set('rgba', numbers(config['rgba']))
    for name, position in mounts.items():
        origin = root.find(f"joint[@name='{name}']/origin")
        origin.set('xyz', numbers(position))
        origin.set('rpy', numbers(config['mounts'][name]['rpy_rad']))
    ET.indent(tree, space='  ')
    urdf = package / 'urdf/rokae_ar5.urdf'
    tree.write(urdf, encoding='utf-8', xml_declaration=True)
    manifest_path = package / 'config/source_manifest.json'
    manifest = json.loads(manifest_path.read_text())
    manifest['meshes'][config['mesh']] = {
        'vertices': len(points), 'triangles': len(triangles),
        'mesh_bounds_m': [points.min(axis=0).tolist(), points.max(axis=0).tolist()],
        'sha256': sha(output), 'source': config['source'], 'source_sha256': sha(source)
    }
    manifest['active_chest'] = {
        'link': 'chest_link', 'mesh': config['mesh'], 'source': config['source'],
        'source_sha256': sha(source), 'cadquery_version': cq.__version__,
        'config': 'config/chest_02.json',
        'config_sha256': sha(config_path), 'solid_count': len(shape.Solids()),
        'source_origin_mm': config['source_origin_mm'],
        'source_to_link_rotation': config['source_to_link_rotation'],
        'mounts_xyz_m': {name: p.tolist() for name, p in mounts.items()},
        'mount_policy': config['mount_policy'], 'physical_mount_calibration_verified': False,
        'inertia_policy': 'No invented density or inertia for the fixed chest'
    }
    manifest['cad_to_link'].pop('30_original_chest_support', None)
    manifest['cad_to_link']['chest_02_adapter'] = 'chest_link'
    manifest['urdf_sha256'] = sha(urdf)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(f'Exported {output.name}: {len(shape.Solids())} solids, {len(triangles)} triangles')
    print('Mounts (m):', {name: p.tolist() for name, p in mounts.items()})
    return manifest['active_chest']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, default=Path(__file__).resolve().parents[1])
    export_chest(parser.parse_args().package)
