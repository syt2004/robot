#!/usr/bin/env python3
"""Export-time comparison with original URDF and current assembly FK (not runtime dependency)."""
import argparse,copy,hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source-root',type=Path,required=True);ap.add_argument('--package',type=Path,default=Path(__file__).resolve().parents[1]);args=ap.parse_args()
    src=args.source_root.resolve();pkg=args.package.resolve();sys.path.insert(0,str(src/'升降前倾底座_评审版'))
    from reachability_core import Arm
    meta=json.loads((pkg/'config/source_manifest.json').read_text());robot=ET.parse(pkg/'urdf/rokae_ar5.urdf').getroot();joints=robot.findall('joint')
    def fk(q):
        frames={'base_link':np.eye(4)};todo=list(joints)
        while todo:
            pending=[]
            for j in todo:
                parent=j.find('parent').get('link')
                if parent not in frames:pending.append(j);continue
                o=j.find('origin');t=np.eye(4)
                if o is not None:t[:3,3]=np.fromstring(o.get('xyz','0 0 0'),sep=' ')*1000;t[:3,:3]=Rotation.from_euler('xyz',np.fromstring(o.get('rpy','0 0 0'),sep=' ')).as_matrix()
                if j.get('type')=='revolute':t[:3,:3]=t[:3,:3]@Rotation.from_rotvec(np.fromstring(j.find('axis').get('xyz'),sep=' ')*q[j.get('name')]).as_matrix()
                frames[j.find('child').get('link')]=frames[parent]@t
            assert len(pending)<len(todo);todo=pending
        return frames
    def canonical(el):return (el.tag,tuple(sorted(el.attrib.items())),tuple(canonical(x) for x in el))
    rng=np.random.default_rng(2026);results={};refs=json.loads((src/'升降前倾底座_评审版/robot_integration_validation.json').read_text())
    for side in ['left','right']:
        a=Arm(side);names=[j.get('name') for j in a.xml.findall('joint') if j.get('type')=='revolute'];qs=np.vstack([a.reference,rng.uniform(a.limits[:,0],a.limits[:,1],size=(100,7))]);Ts,Fs=a.fk(qs);maxpos=maxrot=0.
        for old in a.xml.findall('joint'):
            if old.find('parent').get('link')=='world':continue
            assert canonical(old)==canonical(robot.find(f"joint[@name='{old.get('name')}']"))
        for old in a.xml.findall('link'):
            if old.get('name')=='world':continue
            new=copy.deepcopy(robot.find(f"link[@name='{old.get('name')}']"));expect=copy.deepcopy(old)
            for el in [new,expect]:
                for mesh in el.findall('.//mesh'):mesh.set('filename',Path(mesh.get('filename')).name)
            assert canonical(new)==canonical(expect)
        for row,T,F in zip(qs,Ts,Fs):
            q=dict(meta['initial_joint_positions_rad']);q.update(zip(names,row));got=fk(q)
            for name,want in list(zip(a.links,T))+[(a.flange,F)]:
                maxpos=max(maxpos,float(np.max(abs(got[name][:3,3]-want[:3,3]))));maxrot=max(maxrot,float(np.max(abs(got[name][:3,:3]-want[:3,:3]))))
        assert maxpos<=.01 and maxrot<=1e-6
        results[side]=dict(configurations=101,max_position_error_mm=maxpos,max_rotation_matrix_error=maxrot,official_joints_and_links_preserved=True)
    g=fk(meta['initial_joint_positions_rad']);assert np.max(abs(g['chest_link']-np.array(refs['chest_transform_mm'])))<1e-6
    assert np.max(abs(g['waist_mount'][:3,3]-[108,0,950]))<1e-6
    assert abs(Rotation.from_matrix(g['waist_mount'][:3,:3]).magnitude()-np.pi/6)<1e-8
    for path,h in meta['sources_sha256'].items():assert hashlib.sha256((src/path).read_bytes()).hexdigest()==h
    result=dict(passed=True,seed=2026,arms=results,root='base_link',pedestal_height_mm=1000,waist_center_mm=[108,0,950],tilt_deg=30,source_hashes_unchanged=True)
    (pkg/'config/kinematics_validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
