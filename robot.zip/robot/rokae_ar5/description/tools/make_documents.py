#!/usr/bin/env python3
"""Generate PDF documentation; export-time matplotlib dependency only."""
from pathlib import Path
import json,math,unicodedata
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
from matplotlib.backends.backend_pdf import PdfPages
ROOT=Path(__file__).resolve().parents[1]
font='/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf';font_manager.fontManager.addfont(font)
plt.rcParams.update({'font.family':['DejaVu Sans',font_manager.FontProperties(fname=font).get_name()],'pdf.fonttype':42,'axes.unicode_minus':False})
def pdf(path,title,text,pictures=()):
 lines=[]
 for raw in text.splitlines():
  line='';width=0
  for ch in raw:
   n=2 if unicodedata.east_asian_width(ch) in ('W','F') else 1
   if width+n>94:lines.append(line);line='';width=0
   line+=ch;width+=n
  lines.append(line)
 with PdfPages(path,metadata={'Title':title}) as out:
  for start in range(0,len(lines),45):
   fig=plt.figure(figsize=(8.2677,11.6929));fig.text(.07,.95,title,fontsize=15,color='#184d70')
   for i,line in enumerate(lines[start:start+45]):fig.text(.07,.90-.018*i,line,fontsize=8.8,va='top')
   fig.text(.07,.035,'rokae_ar5 0.1.0 | ROS 2 Humble | R04 / 30°',fontsize=8,color='#66727c');out.savefig(fig);plt.close(fig)
  for name,p in pictures:
   fig=plt.figure(figsize=(11.6929,8.2677));fig.suptitle(name,fontsize=15);ax=fig.add_axes([.035,.055,.93,.86]);ax.imshow(plt.imread(p));ax.axis('off');out.savefig(fig);plt.close(fig)
usage='''整机资源包：rokae_ar5（ament_cmake，ROS 2 Humble）

1. 当前构型
底座最高点1000 mm；安装面中心(108,0,950) mm；安装面前倾30°。
根坐标系base_link位于立柱轴线对应地面，X前、Y左、Z上。
URDF长度用米，关节角用弧度。46个link、45个joint，14个活动关节。
底座25个CAD实体固定安装；脚轮、调平脚保留当前工作姿态。
胸部和机械臂挂接变换与R04装配一致；末端法兰固定90 mm偏移保留。

2. 本机直接启动（官方缺失依赖已在用户目录构建）
source /opt/ros/humble/setup.bash
source "$HOME/.local/share/rokae_ar5_humble/local_setup.bash"
ros2 launch rokae_ar5 display.launch.py

关闭关节滑块界面：
ros2 launch rokae_ar5 display.launch.py gui:=false
仅发布关节状态与TF：
ros2 launch rokae_ar5 display.launch.py gui:=false rviz:=false
请在具有桌面显示的终端运行RViz2。关闭启动终端用Ctrl+C。

3. 复制到其他Humble工作空间
mkdir -p ~/ros2_ws/src
cp -a /path/to/rokae_ar5 ~/ros2_ws/src/
source /opt/ros/humble/setup.bash
cd ~/ros2_ws
rosdep install --from-paths src/rokae_ar5 --ignore-src -r -y
colcon build --packages-select rokae_ar5
source install/setup.bash
ros2 launch rokae_ar5 display.launch.py

依赖安装也可使用Ubuntu22.04/ROS2软件源：
sudo apt install ros-humble-robot-state-publisher \\
  ros-humble-joint-state-publisher ros-humble-joint-state-publisher-gui \\
  ros-humble-rviz2 ros-humble-ament-cmake ros-humble-launch-ros
本包不包含ROS本体；标准Humble依赖安装后，构建和显示不需要联网。
普通构建即可，无须--symlink-install。运行不依赖本项目其他目录。

4. RViz2与关节操作
默认固定坐标系base_link；RobotModel订阅/robot_description。
/joint_states驱动robot_state_publisher，发布/tf和/tf_static。
默认显示原始外观；Collision Enabled关闭；TF显示可手动开启。
关节窗口提供左右臂各7个滑块；名称保留官方URDF名称，08L为左臂，08R为右臂。
初始角度（度）：左[0,90,-90,85,0,0,0]；右[0,-90,-90,85,0,0,0]。
GUI滑块为离散值，初始显示会有微小量化误差；无GUI模式精确发布配置值。
各滑块只遵守官方单关节上下限；不执行腕部耦合约束或任何碰撞过滤。

5. 主要文件与再生成
urdf/rokae_ar5.urdf：整机静态URDF，无运行时xacro或CAD转换。
meshes/：底座、胸部米制STL；官方双臂STL原样复制并保留0.001缩放。
launch/display.launch.py、rviz/rokae_ar5.rviz：启动与可视化配置。
config/joint_state_publisher.yaml：14轴初始角度，单位rad。
config/source_manifest.json：源哈希、CAD/link映射、局部原点、单位和构型。
config/kinematics_validation.json、runtime_validation.json：验证数据。
docs/验证报告.pdf、rviz2.png、joint_sliders.png：验收及真实运行截图。
tools/export_assets.py --source-root /path/to/rokae_assets：离线再导出。
再导出另需CadQuery/OCP、NumPy、SciPy、PyYAML；不是包构建或运行依赖。
tools/validate_kinematics.py需要源项目分析环境；test/test_assets.py只需Python标准库。
再导出后须重新验证、构建和生成文档，旧报告不代表新模型有效。

6. 模型与许可边界
机械臂visual和collision采用用户指定的官方原始STL，不采用CoACD凸分解。
官方collision已有的关节内部装配相交保留；URDF不包含相邻碰撞豁免规则。
保留官方原有惯量；底座及胸部未提供质量惯量，不填造物理参数。
本包用于展示，不包含MoveIt、SRDF、Gazebo、控制器或真实机器人驱动。
胸部与每侧机械臂原安装孔仍为11孔中8孔匹配，展示不能代替机械安装校核。
原始V2包声明BSD，保留来源记录；本整机包未获得统一对外再许可授权。
package.xml的维护人邮箱为显式占位项，对外发布前由所有者填写真实信息。
本包不修改原始STEP、URDF、STL及既有工厂交付文件。
'''
pdf(ROOT/'README.pdf','rokae_ar5 · 安装与使用说明',usage)
if (ROOT/'config/runtime_validation.json').exists():
 k=json.loads((ROOT/'config/kinematics_validation.json').read_text());r=json.loads((ROOT/'config/runtime_validation.json').read_text())
 text='''验收对象：rokae_ar5，R04固定30°底座＋胸部＋V2双臂。

1. 独立包与构建
包复制到独立临时工作空间，普通colcon build，未使用symlink-install。
缺失的官方joint_state_publisher和GUI从humble分支构建；未改写系统ROS。
安装前缀复制到用户目录，清除旧工作空间环境后只加载Humble和该前缀。
全部42个网格package://路径可解析；网格及URDF哈希验证通过。
CTest资产完整性检查通过；单根、无环、名称唯一，14个活动关节。

2. CAD与运动学
底座CAD最高点1000 mm；安装中心(108,0,950) mm；倾角30°。
胸部矩阵与原装配一致，保留官方双臂关节、惯量、限位与90 mm末端偏移。
固定随机种子2026，每臂101组姿态（当前姿态＋100组限位内角度）。
'''
 for side in ['left','right']:
  a=k['arms'][side];text+=f"{side}：最大位置误差{a['max_position_error_mm']:.3e} mm；旋转矩阵最大元素误差{a['max_rotation_matrix_error']:.3e}。\n"
 text+='''
3. ROS与界面
无GUI与默认GUI启动均验证通过：14轴/joint_states、31个静态TF、14个动态TF。
/robot_description与交付URDF哈希一致；腰部与胸部TF位置和方向正确。
真实GUI对14个滑块逐轴发送左右方向键事件；全部观察到对应ROS关节值变化。
RViz2使用独立X显示及软件OpenGL实际启动，非模型渲染模拟图。
截图人工检查RobotModel状态、部件完整性、比例及界面错误；启动无资源加载错误。
'''
 text+=f"GUI初始角度最大量化误差{r['gui']['max_initial_joint_error_rad']:.8f} rad（{math.degrees(r['gui']['max_initial_joint_error_rad']):.5f}°）；无GUI误差为0。\n"
 text+='''
4. 验证范围
碰撞网格采用官方原始版本；本次不证明无碰撞、路径可行或动力学正确。
未修改源模型；源哈希与数值结果保存在config下；逐轴事件在docs/gui_events.json。
'''
 pdf(ROOT/'docs/验证报告.pdf','rokae_ar5 · 构建与可视化验收',text,[('RViz2 实际运行截图',ROOT/'docs/rviz2.png'),('官方关节滑块界面',ROOT/'docs/joint_sliders.png')])
