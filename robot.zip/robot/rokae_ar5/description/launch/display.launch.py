"""ROS 2 Humble: official arm limits, fixed pedestal, GUI or headless display."""
from pathlib import Path
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition,UnlessCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def source_directory():
    for root in Path(__file__).resolve().parents:
        source = root / 'src/robot/rokae_ar5'
        if (root / 'pyproject.toml').is_file() and (source / 'package.xml').is_file():
            return source
    raise RuntimeError('Cannot locate rokae_ar5 source configuration in the workspace')

def generate_launch_description():
    share=source_directory()
    description={'robot_description':(share/'urdf/rokae_ar5.urdf').read_text()}
    params=[description,str(share/'config/joint_state_publisher.yaml')]
    return LaunchDescription([
        DeclareLaunchArgument('gui',default_value='true',description='Show all 14 joint sliders'),
        DeclareLaunchArgument('rviz',default_value='true',description='Start RViz2'),
        Node(package='robot_state_publisher',executable='robot_state_publisher',parameters=[description],output='screen'),
        Node(package='joint_state_publisher_gui',executable='joint_state_publisher_gui',name='joint_state_publisher',parameters=params,condition=IfCondition(LaunchConfiguration('gui')),output='screen'),
        Node(package='joint_state_publisher',executable='joint_state_publisher',name='joint_state_publisher',parameters=params,condition=UnlessCondition(LaunchConfiguration('gui')),output='screen'),
        Node(package='rviz2',executable='rviz2',arguments=['-d',str(share/'rviz/rokae_ar5.rviz')],condition=IfCondition(LaunchConfiguration('rviz')),output='screen')])
