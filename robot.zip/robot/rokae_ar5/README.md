# AR5 模型与 ROS 2 驱动

本目录统一维护项目整机资产及厂商 ROS 2 0.0.4 的 AR5 裁剪版。
目录本身不是 ROS 包；各子包由 colcon 分别发现和构建。

| 子目录 | ROS 包名 | 内容 |
|---|---|---|
| `description` | `rokae_ar5` | pedestal_01、chest_02、AR5 双臂及整机显示入口 |
| `rokae_description` | `rokae_description` | 厂商 AR5L/AR5R 单臂模型、控制 Xacro、Gazebo 模型 |
| `rokae_hardware` | `rokae_hardware` | 七轴 `rokae_driver7`、`RokaeHardwareInterface7`、SDK、AR5 控制器配置 |
| `rokae_msgs` | `rokae_msgs` | 驱动公共消息和服务 |
| `rokae_xMateAR5L_moveit_config` | 同目录名 | 左臂 MoveIt 配置 |
| `rokae_xMateAR5R_moveit_config` | 同目录名 | 右臂 MoveIt 配置 |
| `rokae_gazebo` | `rokae_gazebo` | AR5 仿真所需世界、碰撞检查及启动入口 |
| `rokae_example` | `rokae_example` | 可用于 AR5 的 MoveIt 轨迹示例 |

项目整机的 `package://rokae_ar5/...` URI、ROS 包名和显示启动命令保持不变。
源码路径改为 `src/robot/rokae_ar5/description/...`。装配工厂、Newton 和 WBC
继续使用该整机模型。厂商单臂模型为 `AR5-5_07L/R-W4C4A2`，项目整机臂资产为
`AR5-5_08L/R-W4C4A6-ZY2`；两套资产保留各自来源，本次整合未用前者替换整机几何或运动学参数。

已删除其他机型的 MoveIt 包、网格、URDF、控制器配置和专用启动文件，
以及六轴独立驱动、六轴 SDK 演示和其他机型预设轨迹示例。公共启动入口只接受
`robot_type:=AR5L` 或 `AR5R`，默认左臂。SDK 头文件和预编译库完整保留，
其中的 `xMateErProRobot` 是 AR5 使用的七轴 SDK 类型，不能按名称中的 Pro 删除。
各厂商子包保留原版本、维护者及许可声明。

## 构建

在仓库根目录执行。首次迁移使用新的构建目录，避免旧 CMake 缓存中的源码路径：

```bash
source /opt/ros/humble/setup.bash
# 仅构建原整机描述包
colcon build --base-paths src/robot/rokae_ar5 \
  --packages-select rokae_ar5 --build-base build/ar5 --install-base install

# 构建全部 AR5 包（需要 MoveIt、ros2_control、Gazebo 等 package.xml 声明的依赖）
colcon build --base-paths src/robot/rokae_ar5 \
  --build-base build/ar5 --install-base install
source install/setup.bash
```

整机带手显示仍使用仓库根目录的构建说明和 `./view_robot.sh`。
厂商单臂入口示例：

```bash
# 原整机资产显示
ros2 launch rokae_ar5 display.launch.py
# AR5 左臂 Gazebo 仿真
ros2 launch rokae_hardware gazebo_moveit.launch.py mode:=sim robot_type:=AR5L
# AR5 右臂 MoveIt + mock hardware
ros2 launch rokae_hardware rokae_moveit_launch.py robot_type:=AR5R use_fake_hardware:=true
```

独立驱动入口为 `ros2 launch rokae_hardware rokae_driver.launch.py`，启动的是
`rokae_driver7`；连接真机时显式传入 `robot_ip`、`local_ip`。
驱动沿用厂商单臂接口，双臂聚合与 WBC 真机接入仍按项目设计另行适配。

## 验证

```bash
source /opt/ros/humble/setup.bash
python3 src/robot/rokae_ar5/test/test_integration.py
python3 src/robot/rokae_ar5/description/test/test_assets.py
python3 src/robot/robot_assembly_factory/test/test_factory.py
```

集成测试仅展开模型和读取配置，不启动节点或连接硬件；检查左右臂的真机、mock、
Gazebo 模型、七轴控制器、网格路径和 MoveIt 元数据。需要 Python `xacro`、`yaml`。

2026-10-09 迁移验证：colcon 发现 8 个包；6 个资源／消息包构建通过；
4 项集成测试（覆盖左右臂共 6 种模型展开）、原整机与装配资产完整性检查、
11 项装配工厂测试、7 项 WBC 模型测试通过。整机 URDF、网格和 SDK 字节保持不变。
模型展开使用临时环境中的 xacro 2.1.1；WBC 使用项目 Newton 虚拟环境。
`rokae_hardware` 和 `rokae_example` 的完整编译分别受本机缺少
`controller_manager`、`moveit_ros_planning_interface` 等开发依赖限制，未连接真机。
