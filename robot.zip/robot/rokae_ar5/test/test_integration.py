"""Check AR5 source packages without starting ROS nodes or connecting hardware.

Run with the ROS Humble environment sourced (xacro and PyYAML required).
"""
import os
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

import xacro
import yaml


ROOT = Path(__file__).resolve().parents[1]


class AR5IntegrationTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        prefix = Path(cls.temp.name)
        index = prefix / 'share/ament_index/resource_index/packages'
        index.mkdir(parents=True)
        cls.packages = {}
        for manifest in ROOT.glob('*/package.xml'):
            name = ET.parse(manifest).findtext('name')
            cls.packages[name] = manifest.parent
            (index / name).touch()
            (prefix / 'share' / name).symlink_to(manifest.parent, target_is_directory=True)
        cls.previous_prefix = os.environ.get('AMENT_PREFIX_PATH')
        os.environ['AMENT_PREFIX_PATH'] = str(prefix) + os.pathsep + (cls.previous_prefix or '')

    @classmethod
    def tearDownClass(cls):
        if cls.previous_prefix is None:
            os.environ.pop('AMENT_PREFIX_PATH', None)
        else:
            os.environ['AMENT_PREFIX_PATH'] = cls.previous_prefix
        cls.temp.cleanup()

    def expand(self, filename, **mappings):
        return ET.fromstring(xacro.process_file(
            str(ROOT / 'rokae_description/urdf' / filename), mappings=mappings).toxml())

    def check_model(self, model, side, plugin):
        joints = {j.get('name') for j in model.findall('joint') if j.get('type') != 'fixed'}
        self.assertEqual(joints, {f'joint{i}' for i in range(1, 8)})
        control = model.find('ros2_control')
        self.assertEqual(control.findtext('hardware/plugin'), plugin)
        self.assertEqual({j.get('name') for j in control.findall('joint')}, joints)
        links = {link.get('name') for link in model.findall('link')}
        for joint in model.findall('joint'):
            self.assertIn(joint.find('parent').get('link'), links)
            self.assertIn(joint.find('child').get('link'), links)
        for mesh in model.findall('.//mesh'):
            uri = mesh.get('filename')
            self.assertTrue(uri.startswith('package://'), uri)
            owner, relative = uri[10:].split('/', 1)
            self.assertTrue((self.packages[owner] / relative).is_file(), uri)
        for suffix in ('controllers', 'real_controllers'):
            path = ROOT / f'rokae_hardware/config/xMateAR5{side}_{suffix}.yaml'
            config = yaml.safe_load(path.read_text())
            self.assertEqual(set(config['arm_controller']['ros__parameters']['joints']), joints)

    def test_real_and_mock_models(self):
        for side in 'LR':
            for fake in ('false', 'true'):
                with self.subTest(side=side, fake=fake):
                    model = self.expand('xMate.urdf.xacro', robot_type='AR5' + side,
                                        use_fake_hardware=fake)
                    plugin = ('mock_components/GenericSystem' if fake == 'true'
                              else 'rokae_hardware/RokaeHardwareInterface7')
                    self.check_model(model, side, plugin)

    def test_gazebo_models(self):
        for side in 'LR':
            with self.subTest(side=side):
                model = self.expand(f'AR5-5_07{side}-W4C4A2.urdf.xacro_Gazebo.urdf.xacro')
                self.check_model(model, side, 'gazebo_ros2_control/GazeboSystem')
                for params in model.findall('.//gazebo/plugin/parameters'):
                    self.assertTrue(Path(params.text).is_file())

    def test_unknown_model_rejected(self):
        with self.assertRaises(xacro.XacroException):
            self.expand('xMate.urdf.xacro', robot_type='unsupported')

    def test_moveit_metadata(self):
        for side in 'LR':
            package = ROOT / f'rokae_xMateAR5{side}_moveit_config'
            metadata = yaml.safe_load((package / '.setup_assistant').read_text())
            metadata = metadata['moveit_setup_assistant_config']
            urdf = metadata['urdf']
            self.assertTrue((self.packages[urdf['package']] / urdf['relative_path']).is_file())
            srdf = ET.parse(package / metadata['srdf']['relative_path'])
            model = self.expand('xMate.urdf.xacro', robot_type='AR5' + side)
            links = {link.get('name') for link in model.findall('link')}
            joints = {joint.get('name') for joint in model.findall('joint')}
            for joint in srdf.findall('.//joint'):
                self.assertIn(joint.get('name'), joints)
            for chain in srdf.findall('.//chain'):
                self.assertIn(chain.get('base_link'), links)
                self.assertIn(chain.get('tip_link'), links)


if __name__ == '__main__':
    unittest.main()
