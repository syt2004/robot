# 官方手包整理与资产迁移验证

日期：2026-10-05。范围：包整理、手状态显示、资产引用与现有仿真回归。未连接真实设备，未使能、回零或运行动作示例。

| 检查 | 结果 |
|---|---|
| ROS Humble colcon 包发现 | 五个手部包及 rokae_ar5、robot_assembly_factory 共七包正确识别；模型目录内的 package.xml 未成为独立构建包 |
| 七包构建 | 全部通过；更新显示 launch 后重新构建描述包和工厂通过 |
| 官方来源比较 | 全部模型、网格、SDK、接口及服务源码与上游快照一致；已有文件的本地变化仅显示桥接、launch、描述包依赖，另新增映射模块及测试 |
| 状态映射单元测试 | 4 项通过：mimic 系数／偏移及乱序电机 ID、左右身份筛选、重复／乱序／陈旧时间戳、无效或不完整数据 |
| ROS 显示桥接检查 | 合成 HandJointState 保留原始时间戳；第二次定时发布不重发缓存；其他手样本不污染当前手；不启动硬件服务 |
| 显示 launch 启停 | DH116S 左模型及 left_hand_ 前缀启动两个发布节点，正常退出；RViz关闭，未启动硬件服务 |
| 工厂测试 | CTest 2 项通过，其中包含 11 项工厂行为测试和资产结构校验 |
| 组装与官方模型 FK | 101 组姿态通过；最大位置误差约 2.22e-13 mm，最大旋转矩阵元素误差约 3.33e-16 |
| 整机结构 | 80 links、79 joints、14 臂主动＋12 手主动＋10 mimic |
| Newton 资产加载 | 26 主动关节、152 处网格引用解析通过 |
| 现有 Newton 回归 | test_simulation.py 与 test_joint_control.py 共22项通过 |
| 文档本地链接 | 设计目录、仓库入口、灵巧手和工厂 README 检查通过 |

## 派生碰撞资产的处理

官方模型路径变更使生成 URDF 的字节哈希变化。更新来源哈希前，逐项比较迁移前后 XML（只忽略资源路径和材质名称），并比较每个网格文件字节，确认几何、惯量、关节和安装结构一致。保留已有胶囊参数和碰撞对，仅更新 URDF 来源哈希及说明；加载时继续检查每个碰撞网格顶点覆盖，最大外溢约 4.09e-9 m。

`ik_collision.py` 和离线 `capsule_fit.py` 只改用统一资源解析，不修改拟合、碰撞或控制算法。资源路径参与摘要，迁移后的摘要可以变化；历史回放需要匹配其原始资产版本，不应绕过哈希检查。

## 复验命令

仓库根目录：

```bash
source /opt/ros/humble/setup.bash
colcon build --base-paths src/robot/leadtron_lhand src/robot/rokae_ar5 src/robot/robot_assembly_factory
PYTHONPATH=src/robot/leadtron_lhand/hand_control_description python3 -m pytest -q \
  src/robot/leadtron_lhand/hand_control_description/test/test_state_mapping.py
python3 src/robot/robot_assembly_factory/test/test_factory.py
python3 src/robot/robot_assembly_factory/test/test_assets.py src/robot/robot_assembly_factory
python3 src/robot/robot_assembly_factory/tools/validate_assembly.py --source-root src/robot
src/newton_simulation/.venv/bin/python -I -m pytest -q \
  src/newton_simulation/tests/test_simulation.py src/newton_simulation/tests/test_joint_control.py
```

本次构建和安装输出放在 `/tmp/leadtron-migration-{build,install,log}`。离线 FK 工具会刷新配置验证报告，报告明确标识实物安装尚未验证。上游代码格式检查不作为本次功能验证的一部分。

官方单手 URDF 的根 link 带惯量，独立 robot_state_publisher 会输出 KDL 根惯量不支持的提示；为保持官方模型不变，本次保留该提示。TF 显示启停通过，该提示不作为动力学验证结论。九个外部官方参考链接均检查返回 HTTP 200。

## 尚未完成

AR5 07/08 型号兼容、腕部 EtherCAT 从站配置与 PDO/SDO 控制、供电和安装标定、ZED 选型与外参、真机控制周期和长期 MCAP 吞吐仍待硬件联调。统一 ROS Env、数采节点和仿真相机仍是设计，以上通过项不能替代它们的验收。
