from setuptools import find_packages, setup
from glob import glob

package_name = 'sequence_demo_py'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + "/launch", glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='plf',
    maintainer_email='1399600304@qq.com',
    description='Hand control Python sequence demo',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'sequence_caller = sequence_demo_py.sequence_caller:main'
        ],
    },
)
