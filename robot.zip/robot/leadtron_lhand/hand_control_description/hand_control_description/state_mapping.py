"""Convert one selected hand's telemetry using the vendor URDF, without ROS."""
import math
import xml.etree.ElementTree as ET


class HandStateMapping:
    def __init__(self, description, hand_name, prefix='', bus_name='', address=-1,
                 max_age_ns=250_000_000):
        if not hand_name:
            raise ValueError('hand_name must explicitly select a hand')
        if max_age_ns <= 0:
            raise ValueError('max_age_ns must be positive')
        self.hand_name, self.bus_name, self.address = hand_name, bus_name, address
        self.max_age_ns = max_age_ns
        self.last_stamp_ns = -1
        self.active = [prefix + n for n in
                       ('finger11', 'finger12', 'finger21', 'finger31', 'finger41', 'finger51')]
        root = ET.fromstring(description)
        self.names = [j.get('name') for j in root.findall('joint')
                      if j.get('type') != 'fixed']
        self.mimics = {}
        for joint in root.findall('joint'):
            mimic = joint.find('mimic')
            if mimic is not None:
                self.mimics[joint.get('name')] = (
                    mimic.get('joint'), float(mimic.get('multiplier', '1')),
                    float(mimic.get('offset', '0')))
        if set(self.names) - set(self.mimics) != set(self.active):
            raise ValueError('URDF does not match the six vendor motor IDs and joint prefix')
        self.positions([0.] * 6)  # Validate mimic references/cycles before subscribing.

    def positions(self, angles):
        values = dict(zip(self.active, angles))
        pending = dict(self.mimics)
        while pending:
            ready = [name for name, (source, _, _) in pending.items() if source in values]
            if not ready:
                raise ValueError('Unresolved or cyclic URDF mimic')
            for name in ready:
                source, scale, offset = pending.pop(name)
                values[name] = values[source] * scale + offset
        return [values[name] for name in self.names]

    def convert(self, msg, now_ns):
        """Return positions or None; never re-stamp, clamp, or reuse partial samples."""
        if msg.hand_name != self.hand_name:
            return None
        if self.bus_name and msg.bus_name != self.bus_name:
            return None
        if self.address >= 0 and msg.address != self.address:
            return None
        stamp = msg.header.stamp.sec * 1_000_000_000 + msg.header.stamp.nanosec
        if stamp <= 0 or stamp <= self.last_stamp_ns or not 0 <= now_ns - stamp <= self.max_age_ns:
            return None
        if (msg.active_dof != 6 or len(msg.joint_ids) != 6 or len(msg.angles) != 6
                or set(msg.joint_ids) != set(range(1, 7))):
            return None
        if not all(math.isfinite(a) for a in msg.angles):
            return None
        angles = dict(zip(msg.joint_ids, msg.angles))
        positions = self.positions([math.radians(angles[i]) for i in range(1, 7)])
        self.last_stamp_ns = stamp
        return positions
