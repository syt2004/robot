#!/usr/bin/env python3
"""Display selected hand telemetry; this node is not a hardware freshness monitor."""
from pathlib import Path

import rclpy
from ament_index_python.packages import get_package_share_directory
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from sensor_msgs.msg import JointState
from hand_control_interfaces.msg import HandJointState
from hand_control_description.state_mapping import HandStateMapping


class HandStatePublisher(Node):
    def __init__(self):
        super().__init__('hand_state_publisher')
        defaults = {
            'state_topic': '/hand_control/realtime_state',
            'joint_state_topic': 'joint_states',
            'joint_state_publish_rate_hz': 100.0,
            'hand_name': 'hand', 'bus_name': '', 'address': -1,
            'joint_prefix': '', 'state_timeout_sec': 0.25,
            'robot_description': '', 'model_id': 'DH116S-L000-A1',
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value)
        def param(name):
            return self.get_parameter(name).value
        description = param('robot_description')
        if not description:
            model = param('model_id')
            share = Path(get_package_share_directory('hand_control_description'))
            description = (share / 'models' / model / 'urdf' / (model + '.urdf')).read_text()
        self.mapping = HandStateMapping(
            description, param('hand_name'), param('joint_prefix'), param('bus_name'),
            param('address'), int(param('state_timeout_sec') * 1_000_000_000))
        self.pending = None
        self.joint_pub = self.create_publisher(JointState, param('joint_state_topic'), 10)
        self.state_sub = self.create_subscription(
            HandJointState, param('state_topic'), self.state_callback, 10)
        rate = float(param('joint_state_publish_rate_hz'))
        if not 0 < rate < float('inf'):
            raise ValueError('joint_state_publish_rate_hz must be finite and positive')
        self.publish_timer = self.create_timer(1.0 / rate, self.publish_joint_state)

    def state_callback(self, msg):
        positions = self.mapping.convert(msg, self.get_clock().now().nanoseconds)
        if positions is None:
            return
        output = JointState()
        output.header = msg.header
        output.name = self.mapping.names
        output.position = positions
        self.pending = output  # Display may decimate; record original telemetry separately.

    def publish_joint_state(self):
        msg, self.pending = self.pending, None
        if msg is None:
            return
        stamp = msg.header.stamp.sec * 1_000_000_000 + msg.header.stamp.nanosec
        if 0 <= self.get_clock().now().nanoseconds - stamp <= self.mapping.max_age_ns:
            self.joint_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = HandStatePublisher()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
