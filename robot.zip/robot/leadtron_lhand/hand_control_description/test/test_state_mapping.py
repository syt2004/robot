from pathlib import Path
from types import SimpleNamespace as NS
import math
import xml.etree.ElementTree as ET

from hand_control_description.state_mapping import HandStateMapping

MODEL = Path(__file__).parents[1] / 'models/DH116S-L000-A1/urdf/DH116S-L000-A1.urdf'


def sample(stamp=1_000_000_000, **kwargs):
    values = dict(hand_name='left', bus_name='left_bus', address=1, active_dof=6,
                  joint_ids=[6, 5, 4, 3, 2, 1], angles=[60., 50., 40., 30., 20., 10.],
                  header=NS(stamp=NS(sec=stamp // 10**9, nanosec=stamp % 10**9)))
    values.update(kwargs)
    return NS(**values)


def mapper(prefix=''):
    root = ET.parse(MODEL).getroot()
    for joint in root.findall('joint'):
        joint.set('name', prefix + joint.get('name'))
        m = joint.find('mimic')
        if m is not None:
            m.set('joint', prefix + m.get('joint'))
    return HandStateMapping(ET.tostring(root), 'left', prefix, 'left_bus', 1)


def test_vendor_mimic_offsets_and_permuted_motor_ids():
    m = mapper('left_hand_')
    q = dict(zip(m.names, m.convert(sample(), 1_010_000_000)))
    assert math.isclose(q['left_hand_finger11'], math.radians(10))
    for joint in ET.parse(MODEL).getroot().findall('joint'):
        follow = joint.find('mimic')
        if follow is not None:
            expected = q['left_hand_' + follow.get('joint')] * float(follow.get('multiplier')) + float(follow.get('offset'))
            assert math.isclose(q['left_hand_' + joint.get('name')], expected)
    assert len(q) == 11  # Six measured motors plus five derived joints; no fixed joints.


def test_other_hand_bus_or_address_cannot_change_state():
    m = mapper()
    for changes in ({'hand_name': 'right'}, {'bus_name': 'other'}, {'address': 2}):
        assert m.convert(sample(**changes), 1_010_000_000) is None
    assert m.last_stamp_ns == -1
    assert m.convert(sample(), 1_010_000_000) is not None


def test_stale_duplicate_out_of_order_future_and_zero_stamps():
    m = mapper()
    assert m.convert(sample(), 1_300_000_000) is None
    assert m.convert(sample(stamp=0), 0) is None
    assert m.convert(sample(), 900_000_000) is None
    assert m.convert(sample(), 1_010_000_000) is not None
    assert m.convert(sample(), 1_020_000_000) is None
    assert m.convert(sample(stamp=990_000_000), 1_020_000_000) is None


def test_partial_duplicate_ids_or_nan_are_not_padded_from_cache():
    m = mapper()
    for changes in ({'angles': [1.]}, {'joint_ids': [1, 1, 3, 4, 5, 6]},
                    {'angles': [float('nan')] * 6}, {'active_dof': 5}):
        assert m.convert(sample(**changes), 1_010_000_000) is None
    assert m.last_stamp_ns == -1
