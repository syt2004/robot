# Leadtron 灵巧手驱动集合

来自 `tmp/hand_control_ws_lhandpro/src` 的官方工作区快照。本目录是包集合，不是一个 ROS 包。完整迁移并核对 349 个来源文件后，已按用户要求删除原 `tmp/hand_control_ws_lhandpro`；原始来源路径和哈希继续保留用于追溯。

| 包 | 职责 |
|---|---|
| hand_control_interfaces | 原有消息和服务，协议不变 |
| hand_control_service | SDK 服务及 SOEM EtherCAT、CANFD、RS485 通信 |
| hand_control_description | 官方 DH116/DH116S 模型、模型显示、状态桥接 |
| sequence_demo_cpp / sequence_demo_py | 上游命令序列示例；运行前必须检查动作内容 |

官方模型唯一来源为 `hand_control_description/models`；工厂直接读取 DH116S 左右模型并添加左右前缀。旧 `lhandpro_description` 已退出使用。来源哈希见 `UPSTREAM_MANIFEST.json`，原始说明保留为 `UPSTREAM_README.md`；它是上游快照，里面的工作空间路径与拓扑不是本仓库的默认部署方案。

## 文档与来源索引

- [上游 README](UPSTREAM_README.md)：官方工作空间使用说明，保留原文。
- [ROS2 示例工程说明（中文）](docs/ROS2%20示例工程说明.md)：结构、运行链路、配置、示例与排错。
- [ROS2 Example Project Description（英文）](docs/ROS2%20Example%20Project%20Description.md)：对应英文说明。
- [上游根许可证](LICENSE)：包内 SDK、SOEM 等第三方文件仍遵循其各自许可证。
- [动态库路径配置示例](ros2_hand_control.conf)：保留上游路径，仅供参考；不能直接作为当前工作空间配置安装到系统。
- [上游忽略规则快照](UPSTREAM.gitignore)：归档原工作空间规则，不作为当前仓库 `.gitignore` 生效。
- [来源清单](UPSTREAM_MANIFEST.json)：`sha256` 记录五个包的原始文件，`workspace_files` 记录上述根目录及文档文件的来源、目标和哈希。

上游文档仍按原来的 `hand_control_ws/src/<包名>` 布局描述命令；当前包目录位于 `src/robot/leadtron_lhand/<包名>`，工作空间构建产物位于仓库根目录 `install/`。文档中的系统配置命令未执行；本文的本地适配说明优先于上游显示桥接说明。

## 构建和无硬件显示

在仓库根目录执行：

```bash
source /opt/ros/humble/setup.bash
colcon build --base-paths src/robot/leadtron_lhand src/robot/rokae_ar5 src/robot/robot_assembly_factory
source install/setup.bash
ros2 launch robot_assembly_factory display.launch.py
```

以上显示整机不启动手服务，不连接硬件。显示某只手的已有遥测时，可以启动：

```bash
ros2 launch hand_control_description display.launch.py \
  model_id:=DH116S-L000-A1 hand_name:=left_hand joint_prefix:=left_hand_
```

将 `hand_name` 改为服务配置中该手的实际名称；可加 `bus_name`、`address` 筛选及 `state_topic`。两只手使用各自 model_id/name/prefix；整机运行只启动一个整机 robot_state_publisher，两个桥接节点发布对应前缀的关节状态，不再启动两套独立 TF。

## 通信边界

目标接线为机械臂腕部 EtherCAT 接 DH116S；手册已证明物理端口存在，但尚未证明控制器可直接接入该手。缺少厂商从站描述、PDO/SDO 映射和上位机访问路径，见 [真机接入设计](../../../docs/design_docs/ROS2节点化设计.md#5-真机接入依据与待核实条件)。

现有 EtherCAT 驱动使用电脑 SOEM 主站，仅适用于电脑直接控制的独立手总线。不能把它当作机器人控制器后的透传接口，也不能直接在机器人的内部总线上启用另一主站。上游 `service.yaml` 保留 CANFD 示例默认值，避免将未验证的腕部方案伪装为可直接运行配置；未来统一 Env 的目标总线为 EtherCAT。所有地址、channel、供电和型号必须按现场配置；双手上游示例的 `LAC_DOF_6` 不应直接当作 DH116S 的 `LAC_DOF_6_S`。

本次不运行服务节点或动作示例，不修改厂商 SDK 行为，不添加设备使能、回零或自动恢复。

## 本地适配及数据限制

- SOEM 的 `.gitattributes` 追加 `* -text`，关闭 Git 换行转换以保留厂商文件的原始哈希；原规则逐字节保存在 [SOEM_UPSTREAM.gitattributes](SOEM_UPSTREAM.gitattributes)。来源清单中的该规则文件哈希指原始副本，本地 `.gitattributes` 属于明确记录的适配。

- `hand_state_publisher` 改为从 URDF 读取 mimic 系数及偏移；按电机 ID 排序，过滤其他手／总线／地址，支持整机前缀。
- bridge 默认最多 100 Hz 显示，只发布新收到且通过检查的完整六电机样本；默认时间有效期 0.25 秒，可通过 `state_timeout_sec` 配置。旧值不会被重新赋予当前时间。重复、乱序、未来／零时间戳和非有限数据不发布。
- 自定义前缀运行桥接节点时，`robot_description` 必须带相同前缀；显示 launch 会同步处理模型与桥接。服务和桥接必须使用同一 ROS 时钟；源时钟重置后需重启桥接，不能以旧的时间序列继续验收。
- 显示允许合并到最新样本，不是数据采集管道。录制原始 `HandJointState`；SDK 内部缓存可能仍被上游服务重新封装，桥接无法证明硬件级新鲜度。后续 Env 需补充源计数、读取结果及字段质量。
- 官方模型文件保持原样；改动集中在显示节点、launch、依赖声明和验证。保留上游接口、服务与示例；SDK、SOEM 和资产各自的许可继续适用。

详细架构见 [机器人描述设计](../../../docs/design_docs/robot_description_design.md)。

本次构建、资产对比与仿真回归结果见 [验证记录](VALIDATION.md)。
